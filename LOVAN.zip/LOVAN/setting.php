<?php
include 'localhost.php';
session_start();

// 检查用户是否已登录
if (!isset($_SESSION["email"])) {
    // 用户未登录，重定向到登录页面
    header("Location: login.php");
    exit();
}

if (isset($_POST['logout'])) {
    // 销毁会话数据
    session_destroy();

    // 重定向到登录页面
    echo '<script>
                alert("Bye!");
                window.location.href = "login.php";
            </script>';
        exit();
}

$email = $_SESSION["email"];
$nameuser = $_SESSION["nameuser"];
$gender = $_SESSION["gender"];

if (isset($_POST['usersave'])) {
    // 获取表单数据
    $newUsername = $_POST['newUsername'];
    $newEmail = $_POST['newEmail'];
    $newconfirmEmail = $_POST['newconfirmEmail'];
    $userid = $_SESSION["userid"];  // 获取 userid

    if ($newEmail != $newconfirmEmail) {
        echo '<script>
                alert("Email confirmation does not match!");
                window.location.href = "setting.php";
            </script>';
        exit();
    }

    // 检查邮箱是否已经注册
    $emailCheckQuery = "SELECT * FROM `signup` WHERE `email` = '$newEmail' AND `userid` != '$userid'";
    $emailCheckResult = $conn->query($emailCheckQuery);

    if ($emailCheckResult->num_rows > 0) {
        // 邮箱已经注册
        echo '<script>
                alert("Email has already been registered!");
                window.location.href = "setting.php";
            </script>';
        exit();
    }

    // 更新数据库
    $sql = "UPDATE `signup` SET `nameuser`='$newUsername', `email`='$newEmail' WHERE `userid`='$userid'";

    if ($conn->query($sql) === TRUE) {
        echo '<script>
                alert("User information updated successfully!");
                window.location.href = "login.php";
            </script>';
    } else {
        echo '<script>
                alert("Error updating user information: ' . $conn->error . '");
                window.location.href = "setting.php";
            </script>';
    }
}

if (isset($_POST['pswsave'])) {
    // 获取表单数据
    $orginalpsw = $_POST['orginalpsw'];
    $newpsw = $_POST['newpsw'];
    $confirmpsw = $_POST['confirmpsw'];
    $userid = $_SESSION["userid"];  // 获取 userid

    // 验证原始密码是否匹配
    $checkPasswordQuery = "SELECT password1 FROM signup WHERE userid = '$userid'";
    $checkPasswordResult = $conn->query($checkPasswordQuery);

    if ($checkPasswordResult->num_rows > 0) {
        $row = $checkPasswordResult->fetch_assoc();
        $storedPassword = $row["password1"];
    
        if (password_verify($orginalpsw, $storedPassword)) {
            // 原始密码匹配，继续进行密码更新逻辑
            if ($newpsw != $confirmpsw) {
                // 新密码确认不匹配
                echo '<script>
                        alert("Password confirmation does not match!");
                        window.location.href = "setting.php";
                    </script>';
                exit();
            }
            else{
                $updatePasswordQuery = "UPDATE `signup` SET `password1`='$newpsw' WHERE `userid`='$userid'";
                echo '<script>
                            alert("Password updated successfully!");
                            window.location.href = "login.php";
                        </script>';
            }
        } else {
            // 原始密码不匹配
            echo '<script>
                    alert("Incorrect original password!");
                    window.location.href = "setting.php";
                </script>';
            exit();
        }
    } else {
        // 查询用户密码失败
        echo '<script>
                alert("Error checking original password: ' . $conn->error . '");
                window.location.href = "setting.php";
            </script>';
        exit();
    }    
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="icon" href="Webimage/logo.png" type="image/x-icon"/>
        <title>Setting</title>
        <script src="menu.js"></script>
        <style>
            @font-face {
            font-family: 'Arial Rounded MT Bold';
            src: url('LOVAN/Arial Rounded MT Bold.ttf') format('truetype'),url('LOVAN/Jack Armstrong.ttf') format('truetype');
            }

            * {
                margin: 0;
                padding:1vh;
                
            }
            body {
                height: 100vh;
                width: 100vh;
                display: flex;
                overflow: hidden;
                background-image: linear-gradient(90deg, rgb(98,67,126) , rgb(98,67,126) ,rgb(62,50,69) ,rgb(32,33,31) , rgb(32,33,31) , rgb(32,33,31) ,rgb(32,33,31));
                background-repeat: no-repeat;
            }   
            .menu{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:2vh;  margin:auto; 
                width: 35vh;
                height: 90vh;
                border-radius: 5vh;
                align-items: center;                
                padding: 1vh;
                padding-top: 3vh;
                backdrop-filter: blur(15px);
                background:rgba(255,255,255,0.05);
                margin-left:5vh;
                margin-top: 2.5vh;
            }
            
            .fivegirl{
                display: flex;
                position:absolute; right:0.3vh; left:0;  margin:auto; 
            }

            .link-top {
                width: 70%;
                border-top: solid white 2px;
                margin-top: 5vh;
                display: flex;
                position:absolute; top:13vh; right:0; left:0;  margin:auto; 

            }
            .menubtn{
                display: flex;
                flex-direction: column;
                position:absolute;  top:13vh; left:5vh; 
            }
            .teamother{
                margin-bottom: -2vh;
            }
            .teambtn{
                color: none;
                height: 3.5vh;
                letter-spacing: 4px;
                text-decoration: none;
                font-size: 15px;
                transition: 0.2s;
                background: none;
                border-color: transparent;
                border-radius: 5px;
                color: white;
                font-weight:bold;
                padding: 0vh 0vh;
                border-color: none;
                
            }
            button:hover {
                color: #e7d292;
                background: none;
            }
            #now{
                color: #e7d292;
            }
            .icon{
                margin-left: -2vh;
            }
            
            .musicplayer{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 3vh; right:0; left:2vh;   
                width: 28vh;
                height: 30vh;
                border-radius: 1vh;
                align-items: center;            
                padding: 10vh;
                padding-top: 3vh;
                background: rgb(83,63,103);  
                margin-left:1.5vh;
                margin-top: 1vh;
                box-shadow:0 0 1vh white;
                justify-content: center;
                flex-wrap:center;   
                overflow: hidden; 
            }
            .SongName{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 11vh; right:0; left:2.7vw;   
                width: 8vw;
                height: 5vh;   
                background: none;  
                justify-items: center;
                flex-wrap:center;   
                overflow: hidden;
                text-align: center;
                margin:0;
                padding:0;
                text-justify:center;
            }
            .ArtistName{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 8vh; right:0; left:1.63vw;   
                width: 10vw;
                height: 4vh;   
                background: none;  
                justify-items: center;
                flex-wrap:center;   
                overflow: hidden;
                text-align: center;
                text-justify:center;
                margin:0;
                padding:0;

                
            }
            .SongName h4 {
                color: white;
                text-align: center;
                white-space: nowrap;
                text-overflow: ellipsis;
                margin: 0;
            }

            .ArtistName h6 {
                color: white;
                text-align: center;
                white-space: nowrap;
                text-overflow: ellipsis;
                margin: 0;
            }
            .marquee {
                animation: marquee 25s linear infinite;
            }
            @keyframes marquee {
                0% {
                    transform: translateX(0%);
                }
                100% {
                    transform: translateX(-100%);
                }
            }
            .cd{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                display: flex;
                position:absolute; top:0vh; left:7vh;  margin:auto;
            }
            .cd:hover{
                background-color: none;
            }
            .cd.clicked img {
                content: url('Webimage/pause_btn.PNG');
            }
            
            .controlpannel{
                display: flex;
                position:absolute; top:21vh; left:2vh;
            }
            .controlbtn{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
            }
            .searchbar{
                display: flex;
                position:absolute; top:5.5vh; right:0; left:23vw;  margin:auto; 
            }
            .searchteam{
                display: flex;
                position:absolute; 
                width: 60vw;
                height: 7vh;
                border-radius: 2vh;
                align-items: top;            
                padding: 2vh;
                background: rgba(71,53,90,50%);
                justify-content: left;
                backdrop-filter: blur(15px);
                margin-top: 0vh;
            }
            .search{
                margin-left: -0.5vw;
                margin-top:-1.5vh; 
            }
            
            input{
                width: 100%;
                background: transparent;
                color:white;
                padding: 10px 20px;
                font-size: 18px;
                outline: none;
                border: none;
                font-weight:bold;
                margin-left:-1.5vw;
                font-family: 'Arial Rounded MT Bold', sans-serif;
                 
            }
            
            .micro_btn{
                display: flex;
                position:absolute; top:0vh; right:0; left:56vw;  margin:auto; 
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                flex-wrap: left;
                
            }
            .name{
                display: flex;
                position: absolute;
                top: -12.5vh;
                right: 0;
                left: 60vw;
                font-weight:bold;
            }
            .Username{
                color: white;
                align-items: center;
                display: flex;
                position:absolute; top:15vh;   margin:auto;
                text-transform:capitalize;
            }
            .sex{
                display: flex;
                position: absolute;
                top: 2vh;
                right: 0;
                left: 67vw;
            }
            .change{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:15vw; top:15vh; margin:auto; 
                width: 70vw;
                height: 80vh;
                align-items: start;                
                padding: 1vh;
                background:none;
            }
            .change h4{
                color:white;
                font-weight:bold;
                letter-spacing:0.8vh;
                margin-left:1vw;
                font-size:30px;
            }
            .change img{
                position:absolute;
                left:13vw; 
                top:2vh;
                width:4vw;
            }
            .update{
                display: flex;
                flex-direction: row;
                border:none;
                width:100%;
                height:70%;
            }
            .userinfo{
                display: flex;
                flex-direction: column;
                border:none;
                justify-content: center; 
                align-items: center;
                width:50%;
                height:100%;
            }
            .userinfo form{
                display: flex;
                flex-direction: column;
                justify-content: center; 
                align-items: center;
            }
            .pswupdate form{
                display: flex;
                flex-direction: column;
                justify-content: center; 
                align-items: center;
            }
            .update h5{
                color:rgba(255,255,255,80%);
                font-weight:bold;
                letter-spacing:0.5vh;
                margin-left:1vw;
                font-size:25px;
                text-align: center;
            }
            .update input{
                background:rgba(255,255,255,10%);
                margin:0;
                margin-top:1vh;
                margin-bottom:2vh;
                width:120%;
                color:#e7d292;
                font-weight:none;
                border-radius:1vh;
                letter-spacing:0.2vh;
                border:none;
            }
            .update button{
                width:10vw;
                padding:2vh;
                height:4vw;
                margin-top:2vh;
                font-size:20px;
                border:none;
                border-radius:1vh;
                font-weight:bold;
                background:#F7E0A5;
            }
            .update button:hover{
                font-size:20px;
                border-radius:1vh;
                border:none;
                font-weight:bold;
                color:black;
                box-shadow: 0 0 2vw #F7E0A5;
            }
            .pswupdate{
                display: flex;
                flex-direction: column;
                justify-content: center; 
                align-items: center;
                border:none;
                width:50%;
                height:100%;
            }
            .logout{
                width:100%;
                height:30%;
                border:none;
                padding:0;
                align-items: start;
                display: flex;
                justify-content: center;
            }
            .logout button{
                font-size:20px;
                font-family: 'Jack Armstrong', sans-serif;
                background:none;
                border:none;
                color:white;
                letter-spacing:0.2vh;
                margin-top:2vh;
            }
            .logout button:hover{
                background:none;
                border:none;
                color:#c499cf;
                text-shadow: 0 0 2vh #c499cf;
            }
        </style>
    </head>
    <body>
        <?php include 'localhost.php';?>
        <div class="menu">
            <img src="Webimage/fivegirls.png" class="fivegirl" alt="welcome photo" width="75%" height="10%">
            <div class="link-top"></div>
            <div class="menubtn">
                <div class="teamother">
                    <img src="Webimage/home_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_home()">Home</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/history_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_history()">History</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/favoritesongs_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn"  onclick="go_to_favorite()">Favorite</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/trendind_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_trending()">Trending</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/upgrade_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_upgrade()">Upgrade</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/artists_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_artists()">Artists</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/album_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_album()">Album</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/style_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_style()">Style</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/setting.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" id="now" onclick="go_to_setting()">Setting</button>
                </div>
            </div>
            <div class="musicplayer">
                <button class="cd" onclick="go_to_song()">
                    <img src="Webimage/cd_btn.PNG"  width="70%" alt="cd" >
                </button>
                <div class="SongName">
                    <h4  id="songName">Song Name</h4>
                </div>
                <div class="ArtistName">
                    <h6  id="artistName">Artist Name</h6>
                </div>
                <script>
                    document.addEventListener("DOMContentLoaded", function () {
                        checkTextLength();
                    });

                    function checkTextLength() {
                        var songNameElement = document.getElementById("songName");
                        var artistNameElement = document.getElementById("artistName");

                        if (songNameElement.scrollWidth > songNameElement.clientWidth) {
                            songNameElement.classList.add("marquee");
                        }

                        if (artistNameElement.scrollWidth > artistNameElement.clientWidth) {
                            artistNameElement.classList.add("marquee");
                        }
                    }
                </script>
                <div class="controlpannel">
                    <button class="controlbtn"><img src="Webimage/backsong_btn.PNG"   width="70%"></button>
                    <button class="controlbtn" onclick="toggleImage()"><img src="Webimage/play_btn.PNG"  width="70%" id="cdImage"></button>
                    <button class="controlbtn"><img src="Webimage/nextsong_btn.PNG"  width="70%"></button>
                </div>
            </div>
        </div>
        <div class="searchbar">
            <div class="searchteam">
                <img src="Webimage/search_icon.PNG" class="search" alt="homeicon" width="7%" height="200%">
                <input type="text" placeholder="Search for songs"  id="textInput" name="search" autocomplete="off">
                <button class="micro_btn" onclick="startSpeechRecognition()"><img src="Webimage/microphone _icon.PNG"  width="110%"></button>
            </div>
            <div class="name">
                <h4 class="Username"><?php echo htmlspecialchars($nameuser); ?></h4>
            </div>
                <?php
                    // 讀取性別
                    $gender = isset($_SESSION['gender']) ? $_SESSION['gender'] : '';

                    // 根據性別顯示不同的圖示
                    if ($gender === 'male') {
                        echo '<img class="sex" src="Webimage/boy_icon.png" alt="Male Icon" width="5%" >';
                    } elseif ($gender === 'female') {
                        echo '<img class="sex" src="Webimage/girl_icon.png" alt="Female Icon" width="5%" >';
                    } else {
                        // 預設為一般圖示
                        echo '<img class="sex" src="Webimage/othersex_icon.png" alt="Default Icon" width="5%" >';
                    }
                ?>
            </div>
        </div>
        <div class="change">
            <h4>Setting</h4>
            <img src="Webimage/setting.PNG">
            <div class="update">
                <div class="userinfo">
                    <h5>Update your information</h5>
                    <form action="setting.php" method="POST">
                        <input type="text" maxlength="8" placeholder="New Username" id="newUsername" name="newUsername" oninput="validateInput(this)" required></input>
                        <input type="email" placeholder="New Email" id="newEmail" name="newEmail" required></input>
                        <input type="email" placeholder="Confirm Email" id="newconfirmEmail" name="newconfirmEmail" required></input>
                        <button type="submit" name="usersave">Save</button>
                    </form>
                </div>
                <div class="pswupdate">
                        <h5>Update your password</h5>
                        <form action="setting.php" method="POST">
                            <input type="password" placeholder="Original password"  id="orginalpsw" name="orginalpsw" required></input>
                            <input type="password" placeholder="New password" id="newpsw" name="newpsw" required></input>
                            <input type="password" placeholder="Confirm password"  id="confirmpsw" name="confirmpsw" required></input>
                            <button type="submit" name="pswsave">Save</button>
                        </form>
                </div>
                <script>
                    function validateInput(inputElement) {
                        var inputValue = inputElement.value;
                        var regex = /^[a-zA-Z0-9]+$/;

                        if (!regex.test(inputValue)) {
                            inputElement.value = inputValue.slice(0, -1);
                        }
                    }
                </script>
            </div>
            <div class="logout">
                <form method="post">
                    <!-- 添加一个提交按钮，触发登出逻辑 -->
                    <button type="submit" name="logout">LOG OUT</button>
                </form>
            </div>
        </div>
    </body>
</html>