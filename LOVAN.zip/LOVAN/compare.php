<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user";

$forgetemail=$_POST['forgetemail'];

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

//require 'vendor/autoload.php';
require 'PHPMailer-6.8.1/src/Exception.php';
require 'PHPMailer-6.8.1/src/PHPMailer.php';
require 'PHPMailer-6.8.1/src/SMTP.php';

$mail = new PHPMailer();


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT signupusername , email , password1 FROM signup";
$result = $conn->query($sql);
$error=0;


if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    if($forgetemail==$row['email'] ){
      $msg ="LOVAN Music Password : ".$row['password1'];
      try {
            $mail->isSMTP();
         
            // SMTP 伺服器的設定，以及驗證資訊  
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            // 底下也可以使用 PHPMailer::ENCRYPTION_SMTPS
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
         
            // SMTP 驗證的使用者資訊
            $mail->Username = 'lovanmusic666@gmail.com';
            $mail->Password = 'jcla wwyk iazb xcnu';
         
            // 信件內容的編碼方式，這在範例中沒有，但若不加中文會有問題       
            $mail->CharSet = "utf-8";
            $mail->Encoding = "base64";
         
            // 寄信者與收信者
            $mail->setFrom('lovanmusic666@gmail.com', 'LOVAN Music');
            $mail->addAddress($forgetemail, $row['signupusername']);
            
            $mail->isHTML(true); // 若是純文字的信，此處用 false
            $mail->Subject = 'LOVAN userpassword';
            $mail->Body =$msg;
         
            $mail->send();
            echo '使用者密碼已寄至註冊郵箱';
        } 
        catch (Exception $e) {
            echo "送出失敗: {$mail->ErrorInfo}";
        }
    }
    else $error++;
  }
  if($error==$result->num_rows) echo "尚未註冊帳號";
} 
else {
  echo "0 results";
}
$conn->close();
?>