<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>语音输入示例</title>
    <style>
        body {
            height: 100vh;
            width: 100vh;
            display: flex;
            overflow: hidden;
            background-image: linear-gradient(90deg, rgb(98,67,126) , rgb(98,67,126) ,rgb(62,50,69) ,rgb(32,33,31) , rgb(32,33,31) , rgb(32,33,31) ,rgb(32,33,31));
            background-repeat: no-repeat;
        }
        /* 漣漪效果的样式 */
        .micro_btn {
            display: flex;
            position: absolute;
            top: 0vh;
            right: 0;
            left: 56vw;
            margin: auto;
            color: none;
            overflow: hidden;
            background: none;
            border: none;
            flex-wrap: left;
        }


        input {
            width: 100%;
            background: transparent;
            color: white;
            padding: 10px 20px;
            font-size: 18px;
            outline: none;
            border: none;
            font-weight: bold;
            margin-left: -1.5vw;
            font-family: 'Arial Rounded MT Bold', sans-serif;
        }
    </style>
</head>
<body>
    <input type="text" placeholder="Search for songs" id="textInput" name="search">
    <button class="micro_btn" onclick="startSpeechRecognition()"><img src="Webimage/microphone _icon.PNG" width="110%"></button>

    <script>
        function startSpeechRecognition() {
            // 检查浏览器是否支持Web Speech API
            if ('webkitSpeechRecognition' in window) {
                // 创建语音识别对象
                var recognition = new webkitSpeechRecognition();

                // 设置语言为中文（可以根据需要更改语言）
                recognition.lang = 'zh-CN';

                // 开始语音识别
                recognition.start();

                // 添加漣漪效果

                // 当识别到语音时触发
                recognition.onresult = function(event) {
                    // 获取识别到的文本
                    var transcript = event.results[0][0].transcript;

                    // 将文本放入输入框
                    document.getElementById('textInput').value = transcript;
                };

                // 当语音识别结束时触发
                recognition.onend = function() {
                    // 可以在这里添加一些结束时的逻辑
                };
            } else {
                alert('抱歉，您的浏览器不支持语音识别功能。');
            }
        }

        // 漣漪效果函
    </script>
</body>
</html>
