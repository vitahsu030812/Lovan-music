<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>LOVAN forget password</title>
</head>
<body>
	<div id="inputContainer">
		<form id="sendemail" action="compare.php" method="POST">
			<h2>輸入註冊Email</h2>
			<p>
				<label for="forgetemail">Email</label>
				<input id="forgetemail" name="forgetemail" type="email" placeholder="bart@gmail.com" required>
			</p>
			<button type="submit" name="forgetBotten">確認</button>
		</form>
	</div>
</body>
</html>