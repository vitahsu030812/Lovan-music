<?php
session_start();

// 检查用户是否已登录
if (!isset($_SESSION["email"])) {
    // 用户未登录，重定向到登录页面
    header("Location: login.php");
    exit();
}

// 获取用户信息
$email = $_SESSION["email"];
$nameuser = $_SESSION["nameuser"];
$gender = $_SESSION["gender"];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="icon" href="Webimage/logo.png" type="image/x-icon"/>
        <title>LOVAN</title>
        <script src="menu.js"></script>
        <style>
            @font-face {
            font-family: 'Arial Rounded MT Bold';
            src: url('LOVAN/Arial Rounded MT Bold.ttf') format('truetype');
            }

            * {
                margin: 0;
                padding:1vh;
                
            }
            body {
                height: 100vh;
                width: 100vh;
                display: flex;
                overflow: hidden;
                background-image: linear-gradient(90deg, rgb(98,67,126) , rgb(98,67,126) ,rgb(62,50,69) ,rgb(32,33,31) , rgb(32,33,31) , rgb(32,33,31) ,rgb(32,33,31));
                background-repeat: no-repeat;
            }   
            .menu{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:2vh;  margin:auto; 
                width: 35vh;
                height: 90vh;
                border-radius: 5vh;
                align-items: center;                
                padding: 1vh;
                padding-top: 3vh;
                backdrop-filter: blur(15px);
                background:rgba(255,255,255,0.05);
                margin-left:5vh;
                margin-top: 2.5vh;
            }
            
            .fivegirl{
                display: flex;
                position:absolute; right:0.3vh; left:0;  margin:auto; 
            }

            .link-top {
                width: 70%;
                border-top: solid white 2px;
                margin-top: 5vh;
                display: flex;
                position:absolute; top:13vh; right:0; left:0;  margin:auto; 

            }
            .menubtn{
                display: flex;
                flex-direction: column;
                position:absolute;  top:13vh; left:5vh; 
            }
            .teamother{
                margin-bottom: -2vh;
            }
            .teambtn{
                color: none;
                height: 3.5vh;
                letter-spacing: 4px;
                text-decoration: none;
                font-size: 15px;
                transition: 0.2s;
                background: none;
                border-color: transparent;
                border-radius: 5px;
                color: white;
                font-weight:bold;
                padding: 0vh 0vh;
                border-color: none;
                
            }
            button:hover {
                color: #e7d292;
                background: none;
            }
            .icon{
                margin-left: -2vh;
            }
            
            .musicplayer{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 3vh; right:0; left:2vh;   
                width: 28vh;
                height: 30vh;
                border-radius: 1vh;
                align-items: center;            
                padding: 10vh;
                padding-top: 3vh;
                background: rgb(83,63,103);  
                margin-left:1.5vh;
                margin-top: 1vh;
                box-shadow:0 0 1vh white;
                justify-content: center;
                flex-wrap:center;   
                overflow: hidden; 
            }
            .SongName{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 11vh; right:0; left:2.7vw;   
                width: 8vw;
                height: 5vh;   
                background: none;  
                justify-items: center;
                flex-wrap:center;   
                overflow: hidden;
                text-align: center;
                margin:0;
                padding:0;
                text-justify:center;
            }
            .ArtistName{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 8vh; right:0; left:1.63vw;   
                width: 10vw;
                height: 4vh;   
                background: none;  
                justify-items: center;
                flex-wrap:center;   
                overflow: hidden;
                text-align: center;
                text-justify:center;
                margin:0;
                padding:0;

                
            }
            .SongName h4 {
                color: white;
                text-align: center;
                white-space: nowrap;
                text-overflow: ellipsis;
                margin: 0;
            }

            .ArtistName h6 {
                color: white;
                text-align: center;
                white-space: nowrap;
                text-overflow: ellipsis;
                margin: 0;
            }

            .marquee {
                animation: marquee 25s linear infinite;
                
            }

            .marquee2 {
                animation: marquee2 20s linear infinite;
            }

            
            @keyframes marquee2 {
                0% {
                    transform: translateX(0%);
                }
                100%{
                    transform: translateX(-150%);
                }
            }

            @keyframes marquee {
                0% {
                    transform: translateX(0%);
                }
                100% {
                    transform: translateX(-100%);
                }
            }
            .cd{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                display: flex;
                position:absolute; top:0vh; left:7vh;  margin:auto;
            }
            .cd:hover{
                background-color: none;
            }
            .cd.clicked img {
                content: url('Webimage/pause_btn.PNG');
            }
            
            .controlpannel{
                display: flex;
                position:absolute; top:21vh; left:2vh;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .controlbtn{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
            }
                      
            .searchbar{
                display: flex;
                position:absolute; top:5.5vh; right:0; left:23vw;  margin:auto; 
            }
            .searchteam{
                display: flex;
                position:absolute; 
                width: 60vw;
                height: 7vh;
                border-radius: 2vh;
                align-items: top;            
                padding: 2vh;
                background: rgba(71,53,90,50%);
                justify-content: left;
                backdrop-filter: blur(15px);
                margin-top: 0vh;
            }
            .search{
                margin-left: -0.5vw;
                margin-top:-1.5vh; 
            }
            
            input{
                width: 100%;
                background: transparent;
                color:white;
                padding: 10px 20px;
                font-size: 18px;
                outline: none;
                border: none;
                font-weight:bold;
                margin-left:-1.5vw;
                font-family: 'Arial Rounded MT Bold', sans-serif;
                 
            }
            
            .micro_btn{
                display: flex;
                position:absolute; top:0vh; right:0; left:56vw;  margin:auto; 
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                flex-wrap: left;
                
            }
            .name{
                display: flex;
                position: absolute;
                top: -12.5vh;
                right: 0;
                left: 60vw;
                font-weight:bold;
            }
            .Username{
                color: white;
                align-items: center;
                display: flex;
                position:absolute; top:15vh;   margin:auto;
                text-transform:capitalize;
            }
            .sex{
                display: flex;
                position: absolute;
                top: 2vh;
                right: 0;
                left: 67vw;
            }
            .change{
                display: flex;
                flex-direction: row;
                position:absolute;  right:0; left:15vw; top:15vh; margin:auto; 
                width: 70vw;
                height: 80vh;
                background:none;
                align-items: center;
            }
            .lyricspart{
                display: flex;
                flex-direction: column;
                position:absolute;  left:0vw;  margin:auto;
                width: 40vw;
                height: 75vh;
                background:none;
                border:0px white solid;
                padding:2vh 2vw;
                
            }
            .lyricspart h5{
                color:#a0d2e3;
                font-weight:bold;
            }
            #lyrics-container{
                display: flex;
                flex-direction: column;
                position:absolute;  left:2vw; top:9vh;margin:auto;
                width: 36vw;
                height: 65vh;
                background:none;
                color:white;
                font-size: 15px;

            }

            .highlight-previous_2 {
                color: rgba(255,255,255,30%); /* 上一行歌詞高亮顏色 */
            }
            .highlight-previous_1 {
                color: rgba(255,255,255,50%); /* 上一行歌詞高亮顏色 */
            }
            .highlight-previous {
                color: rgba(255,255,255,70%); /* 上一行歌詞高亮顏色 */
            }
            .highlight-current {
                color: rgba(255,255,255,100%); /* 當前歌詞高亮顏色 */
                font-weight: bold;
                font-size:23px;
            }
            .highlight-next {
                color: rgba(255,255,255,70%); /* 下一行歌詞高亮顏色 */
            }
            .highlight-next1 {
                color: rgba(255,255,255,50%);  /* 下一行歌詞高亮顏色 */
            }
            .highlight-next2 {
                color: rgba(255,255,255,30%) /* 下一行歌詞高亮顏色 */
            }
            .highlight-next3 {
                color: rgba(255,255,255,5%); /* 下一行歌詞高亮顏色 */
            }
            .function{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0;  margin:auto; 
                width:30vw;
                height: 75vh;
                background:none;
                align-items: center;   
                border:0px white solid;
            }
            .nav{
                display: flex;
                flex-direction: row;
                position:absolute;  right:0;  top:0; margin:auto; 
                width:30vw;
                height: 10vh;
                background:none;
                border:0px white solid;
                justify-content: space-around;
                padding:2vh 2vw;
                align-items:center;
                font-weight:bold;
            }
            .nav a{
                color:#a0d2e3;
                font-weight:bold;
                border: 0; /* 移除原有的邊框 */
            }
            .nav a:hover{
                text-decoration: none;
                cursor:default;
            }
            .nav a.active {
                border-bottom: 3px #a0d2e3 solid; /* 添加只有下方有的邊框 */
            }
            .upnext{
                display: flex none;
                flex-direction: column;
                position:absolute;  right:0; bottom:0; margin:auto; 
                width:30vw;
                height: 65vh;
                background:none;
                border:0px yellow solid;
                justify-content: space-around;
                align-items:center;
                font-weight:bold;
                padding:0;
                overflow:auto;
            }
            .upnext::-webkit-scrollbar {
                width: 0.3vw; /* 设置滚动条的宽度 */
            }

            .upnext::-webkit-scrollbar-track {
                background-color: transparent; /* 设置滚动条轨道的背景色 */
            }

            .upnext::-webkit-scrollbar-thumb {
                background-color: white; /* 设置滚动条滑块的颜色 */
                border-radius: 10vw; /* 设置滚动条滑块的圆角 */
            }

            .upnext::-webkit-scrollbar-thumb:hover {
                background-color: #555; /* 鼠标悬停时滚动条滑块的颜色 */
                width: 0.3vw;
                border-radius: 10vw;
            }
            .upnext table{
                border:0px solid ;
                width:100%;
                max-height:10vh;
                color:white;
                max-height: 100%;
                padding:5vw;
            }
            td:nth-child(1) {
                width: 25%;
                text-align: start;
                white-space: nowrap;
                overflow:hidden;
                vertical-align:top;
                height:6vh;
            }
            .tsn{
                width: 16.5vw;
            }
            td:nth-child(1) img{
                padding:1.5vh;
                border-radius:2vh;
            }
            td:nth-child(2) {
                width: 60%;
                height:5vh;
                text-align: start;
                white-space: nowrap;
                overflow:hidden;
                color:white;
                vertical-align:bottom;
                font-size:20px;
            }
            td:nth-child(3) {
                width: 15%;
                text-align: center;

            }
            tr, td {
                padding: 8px;
                border: 0px solid white;
                padding:0;
                 /* 单元格边框 */
            }
            table:hover{
                background-color:rgba(255, 255, 255, 5%);
                backdrop-filter:blur(5px);
            }
            table:hover td:nth-child(1) img {
                filter: brightness(70%); /* 調整亮度的濾鏡效果 */
                
            }
            table:hover ::after {
                content: ""; /* 空的 content */
                background: url('Webimage/LOVAN.PNG') no-repeat;
                background-size: contain;
                display: flex;
                position: absolute;
                z-index: 1;
                top: 4vh;
                left:4vh;
                width: calc(100% - 8vh); /* 减去左右内边距的宽度 */
                height: calc(100% - 8vh); 
            }
            .songn{
                font-size:25px;
            }
            .singer{
                font-size:10px;
                color:rgba(255,255,255,50%);
                font-weight:normal;
            }
            .like{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
            }
            .page{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0;  top:5vh; margin:auto; 
                width:30vw;
                height: auto;
                background:none;
                border:0px blue solid;
                padding:padding:2vh 2vw;
            }
            .prepage{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                display: flex;
                width:3vw;
                padding:0;
                height:auto;
                top:2vh;
                right:0vw;

            }
            .nextpage{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                display: flex;
                width:3vw;
                padding:0;
                height:auto;
                top:2vh;
                right:0vw;
            }
            .pagechbtng{
                display: flex;
                flex-direction: row;
                position:absolute;  right:0;  top:0; margin:auto; 
                width:30vw;
                height: 5vh;
                background:none;
                border:0px gray solid;
                justify-content: end;
                padding:0;
                align-items:center;
                font-weight:bold;
            }
            .pagechbtng h4{
                right:10vw;
            }
            .song{
                display: flex none;
                flex-direction: column;
                position:absolute;  right:0; bottom:0; margin:0; 
                padding:0;
                width:30vw;
                height: 65vh;
                background:none;
                border:0px red solid;
                align-items: center;
                justify-content: center;
                text-align: center;
            }
            .song img{
                border-radius:2vh;
                align-items: center;
                justify-content: center;
                z-index:1;
            }
            .song h6{
                color:white;
                font-size:15px;
                align-items: center;
                justify-content: center;
            }
            .logop{
                z-index: 3;
                position: absolute; /* 使用绝对定位 */
                top: 1vh; /* 距离父元素上边界的距离 */
                left: 3.5vw; /* 距离父元素左边界的距离 */
                border-radius: 0;
            }
            .song h5{
                color:white;
                font-weight:bold;
                font-size:20px;
                line-height :0.5;
                align-items: center;
                justify-content: center;
            }
            .likea{
                color: none;
                background: none;
                border: none;
                z-index: 3;
                position: absolute; /* 使用绝对定位 */
                top: 1.5vh; /* 距离父元素上边界的距离 */
                right: -17vw; /* 距离父元素左边界的距离 */
                border-radius: 0;
            }
            .related{
                display: flex none;
                flex-direction: column;
                position:absolute;  right:0; bottom:0; margin:auto; 
                width:30vw;
                height: 65vh;
                background:none;
                border:0px blue solid;
                justify-content: space-around;
                align-items:center;
                font-weight:bold;
                overflow:auto;
            }
            .related h4{
                color:white;
                font-weight:bold;
                margin-right:9vw;
            }
            .related::-webkit-scrollbar {
                width: 0.3vw; /* 设置滚动条的宽度 */
            }

            .related::-webkit-scrollbar-track {
                background-color: transparent; /* 设置滚动条轨道的背景色 */
            }

            .related::-webkit-scrollbar-thumb {
                background-color: white; /* 设置滚动条滑块的颜色 */
                border-radius: 10vw; /* 设置滚动条滑块的圆角 */
            }

            .related::-webkit-scrollbar-thumb:hover {
                background-color: #555; /* 鼠标悬停时滚动条滑块的颜色 */
                width: 0.3vw;
                border-radius: 10vw;
            }
        </style>
    </head>
    <body onload="showPage('song')">
        <?php include 'localhost.php'; ?>
        <div class="menu">
            <img src="Webimage/fivegirls.png" class="fivegirl" alt="welcome photo" width="75%" height="10%">
            <div class="link-top"></div>
            <div class="menubtn">
                <div class="teamother">
                    <img src="Webimage/home_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_home()">Home</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/history_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_history()">History</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/favoritesongs_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_favorite()">Favorite</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/trendind_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_trending()">Trending</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/upgrade_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_upgrade()">Upgrade</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/artists_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_artists()">Artists</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/album_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_album()">Album</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/style_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_style()">Style</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/setting.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_setting()">Setting</button>
                </div>
            </div>
            <div class="musicplayer">
                <button class="cd" onclick="go_to_song()">
                    <img src="Webimage/cd_btn.PNG"  width="70%" alt="cd" >
                </button>
                <div class="SongName">
                    <h4  id="songName">Song Name</h4>
                </div>
                <div class="ArtistName">
                    <h6  id="artistName">Artist Name</h6>
                </div>
                <script>
                    /*文字跑馬燈*/
                    document.addEventListener("DOMContentLoaded", function () {
                        checkTextLength();
                    });

                    function checkTextLength() {
                        var songNameElement = document.getElementById("songName");
                        var artistNameElement = document.getElementById("artistName");

                        if (songNameElement.scrollWidth > songNameElement.clientWidth) {
                            songNameElement.classList.add("marquee");
                        }

                        if (artistNameElement.scrollWidth > artistNameElement.clientWidth) {
                            artistNameElement.classList.add("marquee");
                        }
                    }
                    /*文字跑馬燈*/
                </script>

                <div class="controlpannel">
                    <button class="controlbtn"><img src="Webimage/backsong_btn.PNG"   width="70%"></button>
                    <button class="controlbtn" onclick="toggleImage()"><img src="Webimage/play_btn.PNG"  width="70%" id="cdImage"></button>
                    <button class="controlbtn"><img src="Webimage/nextsong_btn.PNG"  width="70%"></button>
                </div>
               <script>
                    
                </script>
            </div>
        </div>
        <div class="searchbar">
            <div class="searchteam">
                <img src="Webimage/search_icon.PNG" class="search" alt="homeicon" width="7%" height="200%">
                <input type="text" placeholder="Search for songs"  id="textInput" name="search" autocomplete="off">
                <button class="micro_btn" onclick="startSpeechRecognition()"><img src="Webimage/microphone _icon.PNG"  width="110%"></button>
            </div>
            <div class="name">
                <h4 class="Username"><?php echo htmlspecialchars($nameuser); ?></h4>
            </div>
                <?php
                    // 讀取性別
                    $gender = isset($_SESSION['gender']) ? $_SESSION['gender'] : '';

                    // 根據性別顯示不同的圖示
                    if ($gender === 'male') {
                        echo '<img class="sex" src="Webimage/boy_icon.png" alt="Male Icon" width="5%" >';
                    } elseif ($gender === 'female') {
                        echo '<img class="sex" src="Webimage/girl_icon.png" alt="Female Icon" width="5%" >';
                    } else {
                        // 預設為一般圖示
                        echo '<img class="sex" src="Webimage/othersex_icon.png" alt="Default Icon" width="5%" >';
                    }
                ?>
            </div>
        </div>
        <div class="change">
            <div class="lyricspart">
                <h5>LYRICS</h5>
                <div id="lyrics-container"></div>
                <script>
                    const lyricsContainer = document.getElementById('lyrics-container');
                    const lyricsText = "\n이런 빌어먹을 세상\n이런 빌어먹을 세상 나만 혼자 바보 됐어\n갈 길을 잃은 채 갈 곳을 잃은 채\n나만 바보 됐어, 나만 바보 됐어\n잊어버리자 이렇게\n웃어 버리자 이렇게 eh-eh-eh-eh\n되도 않는 위로를 해봐도\n집에 돌아가는 길에 울컥\n울고 싶어 계속 whoa-uh-uh, uh\n사라져 가는 내 모습을\n다시 찾고만 싶을 뿐\n어릴 때 만화영화에 나오는 주인공은 왜\n내가 될 수 없는지 내 맘은 아주 검은 색\n나와 하루만 심장 바꿔 줄 사람 어디도 없나\n\n이런 빌어먹을 세상 나만 혼자 바보 됐어\n갈 길을 잃은 채 갈 곳을 잃은 채\n나만 바보 됐어\n지금부터 fight for my life\n나를 위해 fight for my life\n무뎌짐이 익숙한 세상에서\n이제 나는 나를 찾고 싶어\n\n점점 난 지쳐가 혼자서 꾸는 꿈\n이젠 너무나 지겨워 그만두고 싶어\n난 나에게 어제 나에게\n부끄러운 내일이 되고 싶지 않아\n되도 않는다짐을 봐도\n바보 같은 내 모습이 우스워\n울고 싶어 계속 whoa-uh-uh, uh\n세상에 맘이 무뎌져서\n내가 작아지는 기분 (내가 작아지는 기분) \n말할 수 없는 비밀이 또다시 눈물이 되지\n난 부끄러워서 누구에게도 말을 못 했지\n나와 하루만 심장 바꿔 줄 사람 어디도 없나\n이런 빌어먹을 세상 나만 혼자 바보 됐어\n갈 길을 잃은 채 갈 곳을 잃은 채\n나만 바보 됐어\n지금부터 fight for my life\n나를 위해 fight for my life\n무뎌짐이 익숙한 세상에서\n이제 나는 나를 찾고 싶어\n\n무뎌짐이 익숙한 세상에서\n이제 나는 나를 찾고 싶어\n\n\n\n"; // 替換為你的歌詞

                    const lines = lyricsText.split('\n'); // 根據空格分割歌詞成陣列

                    // 簡單的歌詞滾動效果
                    let wordIndex = 0;
                    let scrollInterval;

                    function scrollLyrics() {
                        const previousWord_2 = lines[(wordIndex - 3 + lines.length) % lines.length];
                        const previousWord_1 = lines[(wordIndex - 2 + lines.length) % lines.length];
                        const previousWord = lines[(wordIndex - 1 + lines.length) % lines.length];
                        const currentWord = lines[wordIndex];
                        const nextWord = lines[(wordIndex + 1) % lines.length];
                        const nextWord1 = lines[(wordIndex + 2) % lines.length];
                        const nextWord2 = lines[(wordIndex + 3) % lines.length];
                        const nextWord3 = lines[(wordIndex + 4) % lines.length];

                        lyricsContainer.innerHTML = `<p class="highlight-previous_2">${previousWord_2}</p> <p class="highlight-previous_1">${previousWord_1}</p> <p class="highlight-previous">${previousWord}</p> <p class="highlight-current">${currentWord}</p> <p class="highlight-next">${nextWord}</p> <p class="highlight-next1">${nextWord1}</p> <p class="highlight-next2">${nextWord2}</p> <p class="highlight-next3">${nextWord3}</p>`;
                        wordIndex = (wordIndex + 1) % lines.length;
                        if (wordIndex === lines.length - 4) {
                            clearInterval(scrollInterval);
                        }      
                        
                    }
                    scrollLyrics();

                    
                </script>
            </div>
            <div class="function" >
                <div class="nav">
                    <a onclick="showPage('upnext')" id="upnext-link">UP NEXT</a>
                    <a onclick="showPage('song')" id="song-link">SONG</a>
                    <a onclick="showPage('related')" id="related-link">RELATED</a>
                </div>
                <div class="upnext" id="upnext">
                    <div class="pagechbtng">
                        <button class="prepage" onclick="prevPage()"><img src="Webimage/btn_left.PNG" width="100%"></button>
                        <button class="nextpage" onclick="nextPage()"><img src="Webimage/btn_right.PNG" width="100%"></button>
                    </div>
                    <div class="page" id="page1">
                        <table>
                            <tr>
                                <td rowspan="2"><img src="Webimage/album.PNG" width="100%"></td>
                                <td class="songn" ><div class="tsn" id="songname">God of Musics</div></td>
                                <td rowspan="2"><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                            </tr>
                            <tr>
                                <td class="singer" ><div class="tsn" id="singer">Seventeen</div></td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td rowspan="2"><img src="Webimage/album.PNG" width="100%"></td>
                                <td class="songn" ><div class="tsn" id="songname">God of Musics</div></td>
                                <td rowspan="2"><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                            </tr>
                            <tr>
                                <td class="singer" ><div class="tsn" id="singer">Seventeen123456sssssssssssssssssssssssssssss</div></td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td rowspan="2"><img src="Webimage/album.PNG" width="100%"></td>
                                <td class="songn" ><div class="tsn" id="songname">God of Musicsssssssssssssssssssssssss</div></td>
                                <td rowspan="2"><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                            </tr>
                            <tr>
                                <td class="singer" ><div class="tsn" id="singer">Seventeen123456sssssssssssssssss</div></td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td rowspan="2"><img src="Webimage/album.PNG" width="100%"></td>
                                <td class="songn" ><div class="tsn" id="songname">God of Musicsssssssssssssssssssssssss</div></td>
                                <td rowspan="2"><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                            </tr>
                            <tr>
                                <td class="singer" ><div class="tsn" id="singer">Seventeen123456sssssssssssssssssssssssssssssssss</div></td>
                            </tr>
                        </table>
                    </div>
                    <div class="page" id="page2" style="display: none;">
                        <table>
                            <tr>
                                <td rowspan="2"><img src="Webimage/album.PNG" width="100%"></td>
                                <td class="songn" ><div class="tsn" id="songname">God of Musics</div></td>
                                <td rowspan="2"><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                            </tr>
                            <tr>
                                <td class="singer" ><div class="tsn" id="singer">Seventeen</div></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="song" id="song">
                    <img src="Webimage/album.PNG" width="80%">
                    <img src="Webimage/LOVAN_purple.PNG"  class="logop" width="15%">
                    <h5>Fuck My Life</h5>
                    <h6>Seventeen</h6>
                </div>
                <div class="related" id="related">
                    <div class="pagechbtng">
                        <h4>You might also like</h4>
                        <button class="prepage" onclick="rprevPage()"><img src="Webimage/btn_left.PNG" width="100%"></button>
                        <button class="nextpage" onclick="rnextPage()"><img src="Webimage/btn_right.PNG" width="100%"></button>
                    </div>
                    <div class="page" id="rpg1">
                        <table>
                            <tr>
                                <td rowspan="2"><img src="Webimage/album.PNG" width="100%"></td>
                                <td class="songn" ><div class="tsn" id="songname">God of Musics</div></td>
                                <td rowspan="2"><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                            </tr>
                            <tr>
                                <td class="singer" ><div class="tsn" id="singer">Seventeen</div></td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td rowspan="2"><img src="Webimage/album.PNG" width="100%"></td>
                                <td class="songn" ><div class="tsn" id="songname">God of Musics</div></td>
                                <td rowspan="2"><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                            </tr>
                            <tr>
                                <td class="singer" ><div class="tsn" id="singer">Seventeen123456sssssssssssssssssssssssssssss</div></td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td rowspan="2"><img src="Webimage/album.PNG" width="100%"></td>
                                <td class="songn" ><div class="tsn" id="songname">God of Musicsssssssssssssssssssssssss</div></td>
                                <td rowspan="2"><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                            </tr>
                            <tr>
                                <td class="singer" ><div class="tsn" id="singer">Seventeen123456sssssssssssssssss</div></td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td rowspan="2"><img src="Webimage/album.PNG" width="100%"></td>
                                <td class="songn" ><div class="tsn" id="songname">God of Musicsssssssssssssssssssssssss</div></td>
                                <td rowspan="2"><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                            </tr>
                            <tr>
                                <td class="singer" ><div class="tsn" id="singer">Seventeen123456sssssssssssssssssssssssssssssssss</div></td>
                            </tr>
                        </table>
                    </div>
                    <div class="page" id="rpg2" style="display: none;">
                        <table>
                            <tr>
                                <td rowspan="2"><img src="Webimage/album.PNG" width="100%"></td>
                                <td class="songn" ><div class="tsn" id="songname">God of Musics</div></td>
                                <td rowspan="2"><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                            </tr>
                            <tr>
                                <td class="singer" ><div class="tsn" id="singer">Seventeen</div></td>
                            </tr>
                        </table>
                    </div>                
                </div>
                <script>
                    function showPage(pageId) {
                        // 隱藏所有頁面
                        var pages = document.querySelectorAll('.upnext, .song, .related');
                        for (var i = 0; i < pages.length; i++) {
                            pages[i].style.display = 'none';
                        }

                        // 顯示指定頁面
                        document.getElementById(pageId).style.display = 'block';
                        var links = document.querySelectorAll('.nav a');
                        for (var i = 0; i < links.length; i++) {
                            links[i].classList.remove('active');
                        }

                        // 將激活的頁面標籤添加 "active" 類別
                        document.getElementById(pageId + '-link').classList.add('active');
                    }
                    
                    // 移除所有頁面的 "active" 類別
                    
                    
                    document.addEventListener("DOMContentLoaded", function () {
                            applyMarqueeEffect();
                        });

                        function applyMarqueeEffect() {
                            var tsnElements = document.querySelectorAll('.tsn');
                            tsnElements.forEach(function (element) {
                                // 檢查元素內容的寬度是否超過範圍
                                if (element.scrollWidth > element.clientWidth) {
                                    element.classList.add('marquee'); // 超出範圍時應用跑馬燈效果
                                }
                            });
                        }

                        var currentPage = 1;

                        function changePage(pageNumber) {
                            document.getElementById('page' + currentPage).style.display = 'none';
                            document.getElementById('page' + pageNumber).style.display = 'flex';
                            currentPage = pageNumber;
                            applyMarqueeEffect();
                        }

                        function prevPage() {
                            if (currentPage > 1) {
                                changePage(currentPage - 1);
                            }
                        }

                        function nextPage() {
                            if (currentPage < 2) {
                                changePage(currentPage + 1);
                            }
                        }
                        var rcurrentPage = 1;

                        function rchangePage(rpageNumber) {
                            document.getElementById('rpg' + rcurrentPage).style.display = 'none';
                            document.getElementById('rpg' + rpageNumber).style.display = 'flex';
                            rcurrentPage = rpageNumber;
                            applyMarqueeEffect();
                        }

                        function rprevPage() {
                            if (rcurrentPage > 1) {
                                rchangePage(rcurrentPage - 1);
                            }
                        }

                        function rnextPage() {
                            if (rcurrentPage < 2) {
                                rchangePage(rcurrentPage + 1);
                            }
                        }
                        applyMarqueeEffect();
                </script>
            </div>
        </div>
    </body>
</html>