<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>

<div class="container">
  <h1>My First Bootstrap Page</h1>
  <p>Resize this responsive page to see the effect!</p>
</div>

<div class="container">
  <div class="row">
    <?php

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "example";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $sql = "SELECT name,address FROM ex";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      $name=$row["name"];
      $address=$row["address"];
       echo"
    <div class='col-sm-4'>
      <h3>".$name."</h3>
      <p>".$address."</p>
    </div>";
      
    }
  } else {
    echo "0 results";
  }
  $conn->close();
    ?>

  </div>
</div>
