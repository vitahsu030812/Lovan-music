<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>註冊結果</title>
  <script>
			// 支付表单弹窗
			function success() {
				alert("Registration Success!!!");
			}

      function error(){
        alert("Password Confirmation Error!");
      }

      function sqlno(){
        alert("Error!!!!");
      }
  </script>
</head>
<body>

<?php
include 'localhost.php';

$username = $_POST['username'];
$email = $_POST['email'];
$password1 = $_POST['password1'];
$password2 = $_POST['password2'];
$birthday = $_POST['birthday'];
$gender = $_POST['gender'];


$emailCheckQuery = "SELECT * FROM `signup` WHERE `email` = '$email'";
$emailCheckResult = $conn->query($emailCheckQuery);

if ($emailCheckResult->num_rows > 0) {
  // 電子郵件已經註冊
  echo '<script>
            alert("Email has already been registered!");
            window.location.href = "login.php";
        </script>';
} else {
  // 電子郵件尚未註冊，繼續註冊流程
  if ($password1 == $password2) {
    $sql = "INSERT INTO `signup`(`nameuser`, `email`, `password1`, `birthday` , `gender`) VALUES ('$username', '$email', '$password1', '$birthday','$gender')";
    if ($conn->query($sql) === TRUE) {
      echo '<script>
              success();
              window.location.href = "login.php";
            </script>';
    } else {
      echo '<script>
              sqlno();
              window.location.href = "register.php";
            </script>';
    }
  } else {
    echo '<script>
              error();
              window.location.href = "register.php";
            </script>';
  }
}
$conn->close();
?>

<!-- 一个用于关闭对话框的示例按钮 -->
<button onclick="closeDialog()">關閉</button>

<script>
  function closeDialog() {
    document.querySelector('dialog').close();
  }
</script>

</body>
</html>
