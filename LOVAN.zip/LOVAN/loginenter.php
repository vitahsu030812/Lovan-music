<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登入結果</title>
    <script>
      function loginyes() {
        alert("Enjoy Music Time!!!");
      }

      function sqlerror(){
        alert("SQL Error");
      }

      function loginno(message){
        alert(message);
        window.location.href = "register.php";
      }
    </script>
  </head>
  <body>
    <?php
      include 'localhost.php';
      $loginEmail = $_POST['loginEmail'];
      $loginPassword = $_POST['loginPassword'];

      $sql = "SELECT userid, email, password1, nameuser, gender FROM signup WHERE email = '$loginEmail'";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
        // 用户存在，检查密码
        $row = $result->fetch_assoc();
        if ($loginPassword == $row["password1"]) {
          // 密码正确，进行登录
          echo '<script>
                  loginyes();
                  window.location.href = "home.php";
                </script>';
          // 登录成功，存储用户信息
          session_start();
          $_SESSION["userid"] = $row["userid"]; 
          $_SESSION["email"] = $loginEmail;
          $_SESSION["nameuser"] = $row["nameuser"];
          $_SESSION["gender"] = $row["gender"];
        } else {
          // 密码错误
          echo '<script>
                  loginno("Incorrect password!");
                </script>';
        }
      } else {
        // 用户不存在
        echo '<script>
                loginno("Email not registered! Please sign up.");
              </script>';
      }

      $conn->close();
    ?>
  </body>
</html>
