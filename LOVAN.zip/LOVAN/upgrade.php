<?php
session_start();

// 检查用户是否已登录
if (!isset($_SESSION["email"])) {
    // 用户未登录，重定向到登录页面
    header("Location: login.php");
    exit();
}

// 获取用户信息
$email = $_SESSION["email"];
$nameuser = $_SESSION["nameuser"];
$gender = $_SESSION["gender"];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="icon" href="Webimage/logo.png" type="image/x-icon"/>
        <title>LOVAN Upgrade</title>
        <script src="menu.js"></script>
        <style>
            @font-face {
            font-family: 'Arial Rounded MT Bold';
            src: url('LOVAN/Arial Rounded MT Bold.ttf') format('truetype');
            }

            * {
                margin: 0;
                padding:1vh;
                
            }
            body {
                height: 100vh;
                width: 100vh;
                display: flex;
                overflow: hidden;
                background-image: linear-gradient(90deg, rgb(98,67,126) , rgb(98,67,126) ,rgb(62,50,69) ,rgb(32,33,31) , rgb(32,33,31) , rgb(32,33,31) ,rgb(32,33,31));
                background-repeat: no-repeat;
            }   
            .menu{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:2vh;  margin:auto; 
                width: 35vh;
                height: 90vh;
                border-radius: 5vh;
                align-items: center;                
                padding: 1vh;
                padding-top: 3vh;
                backdrop-filter: blur(15px);
                background:rgba(255,255,255,0.05);
                margin-left:5vh;
                margin-top: 2.5vh;
            }
            
            .fivegirl{
                display: flex;
                position:absolute; right:0.3vh; left:0;  margin:auto; 
            }

            .link-top {
                width: 70%;
                border-top: solid white 2px;
                margin-top: 5vh;
                display: flex;
                position:absolute; top:13vh; right:0; left:0;  margin:auto; 

            }
            .menubtn{
                display: flex;
                flex-direction: column;
                position:absolute;  top:13vh; left:5vh; 
            }
            .teamother{
                margin-bottom: -2vh;
            }
            .teambtn{
                color: none;
                height: 3.5vh;
                letter-spacing: 4px;
                text-decoration: none;
                font-size: 15px;
                transition: 0.2s;
                background: none;
                border-color: transparent;
                border-radius: 5px;
                color: white;
                font-weight:bold;
                padding: 0vh 0vh;
                border-color: none;
                
            }
            button:hover {
                color: #e7d292;
                background: none;
            }
            #now{
                color: #e7d292;
            }
            .icon{
                margin-left: -2vh;
            }
            
            .musicplayer{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 3vh; right:0; left:2vh;   
                width: 28vh;
                height: 30vh;
                border-radius: 1vh;
                align-items: center;            
                padding: 10vh;
                padding-top: 3vh;
                background: rgb(83,63,103);  
                margin-left:1.5vh;
                margin-top: 1vh;
                box-shadow:0 0 1vh white;
                justify-content: center;
                flex-wrap:center;   
                overflow: hidden; 
            }
            .SongName{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 11vh; right:0; left:2.7vw;   
                width: 8vw;
                height: 5vh;   
                background: none;  
                justify-items: center;
                flex-wrap:center;   
                overflow: hidden;
                text-align: center;
                margin:0;
                padding:0;
                text-justify:center;
            }
            .ArtistName{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 8vh; right:0; left:1.63vw;   
                width: 10vw;
                height: 4vh;   
                background: none;  
                justify-items: center;
                flex-wrap:center;   
                overflow: hidden;
                text-align: center;
                text-justify:center;
                margin:0;
                padding:0;

                
            }
            .SongName h4 {
                color: white;
                text-align: center;
                white-space: nowrap;
                text-overflow: ellipsis;
                margin: 0;
            }

            .ArtistName h6 {
                color: white;
                text-align: center;
                white-space: nowrap;
                text-overflow: ellipsis;
                margin: 0;
            }
            .marquee {
                animation: marquee 25s linear infinite;
            }
            @keyframes marquee {
                0% {
                    transform: translateX(0%);
                }
                100% {
                    transform: translateX(-100%);
                }
            }
            .cd{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                display: flex;
                position:absolute; top:0vh; left:7vh;  margin:auto;
            }
            .cd:hover{
                background-color: none;
            }
            .cd.clicked img {
                content: url('Webimage/pause_btn.PNG');
            }
            
            .controlpannel{
                display: flex;
                position:absolute; top:21vh; left:2vh;
            }
            .controlbtn{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
            }
            .searchbar{
                display: flex;
                position:absolute; top:5.5vh; right:0; left:23vw;  margin:auto; 
            }
            .searchteam{
                display: flex;
                position:absolute; 
                width: 60vw;
                height: 7vh;
                border-radius: 2vh;
                align-items: top;            
                padding: 2vh;
                background: rgba(71,53,90,50%);
                justify-content: left;
                backdrop-filter: blur(15px);
                margin-top: 0vh;
            }
            .search{
                margin-left: -0.5vw;
                margin-top:-1.5vh; 
            }
            
            input{
                width: 100%;
                background: transparent;
                color:white;
                padding: 10px 20px;
                font-size: 18px;
                outline: none;
                border: none;
                font-weight:bold;
                margin-left:-1.5vw;
                font-family: 'Arial Rounded MT Bold', sans-serif;
                 
            }
            
            .micro_btn{
                display: flex;
                position:absolute; top:0vh; right:0; left:56vw;  margin:auto; 
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                flex-wrap: left;
                
            }
            .name{
                display: flex;
                position: absolute;
                top: -12.5vh;
                right: 0;
                left: 60vw;
                font-weight:bold;
            }
            .Username{
                color: white;
                align-items: center;
                display: flex;
                position:absolute; top:15vh;   margin:auto;
                text-transform:capitalize;
            }
            .sex{
                display: flex;
                position: absolute;
                top: 2vh;
                right: 0;
                left: 67vw;
            }
            .change{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:15vw; top:15vh; margin:auto; 
                width: 70vw;
                height: 80vh;
                align-items: center;                
                padding: 1vh;
                background:none;
            }
            .upgread_group{
                display: flex;
                position:absolute;  right:0.5vw; left:0.5vw; top:10vh; margin:auto; 
                width: 69vw;
                height: 70vh;
                align-items: center;                
                padding: 1vh;
                background:none;
            }
            
            .upgread_inside_indiv{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:3vw; top:0.5vh; 
                width: 16vw;
                height: 68vh;
                align-items: center;
                box-shadow:0vh 0vh 4vh #f6e59f;
                border-radius:1vh;
                border:3px solid;
                border-color: #f6e59f;                
                background:none;
            }
            .upgread_inside_stu{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:26vw; top:0.5vh; 
                width: 16vw;
                height: 68vh;
                align-items: center;
                box-shadow:0vh 0vh 4vh #e2b1d0;
                border-radius:1vh;
                border:3px solid;
                border-color: #e2b1d0;                
                background:none;
            }
            .upgread_inside_fam{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:49vw; top:0.5vh; 
                width: 16vw;
                height: 68vh;
                align-items: center;
                box-shadow:0vh 0vh 4vh #c4f9ec;
                border-radius:1vh;
                border:3px solid;
                border-color: #c4f9ec;                
                background:none;
            }
            .title{
                font-weight:bold;
                letter-spacing: 3px;
                margin-top: 0;
                font-size: 22px;
                color: white;
            }
            .comp{
                margin-top: 2vh;
                font-weight:bold;
                letter-spacing: 5px;
                font-size: 22px;
                color: white;
            }
            .type{
                font-weight:bold;
                letter-spacing: 2px;
                font-size: 22px;
                color: white;
                margin-top: -7vh;
                padding-top:6vh;
            }
            .linkupgrade {
                width: 70%;
                border-top: solid white 2px;
                margin-top: 0vh;
                display: flex; 
            }
            .content{
                display: flex;
                flex-direction: column;
                justify-content: center ;
                position:absolute;
                width: 12vw;
                height: 30vh;
                top:18vh;
                align-items: left;        
                background:none;
                padding-left: 1vw;
            }
            .content li{
                color: white;
            }
            .price{
                color: white;
                display: flex;
                position:absolute;  
                top:46vh;
                padding-bottom:6vh;
            }
            .get{
                padding: 15px 30px;
                color: #222;
                letter-spacing: 4px;
                text-decoration: none;
                font-size: 30px;
                background: #f6e59f;
                border: none;
                border-radius: 1vh;
                display: flex;
                position:absolute;
                bottom:4vh; 
                width: 12vw;
                height: 9vh;   
                align-items:center;
                justify-content:center;
                font-weight:bold;
                cursor: pointer;
                text-transform:uppercase;
                transition:0.5s;  
            }
            .get:hover{
                color: #fff;
                background: #f6e59f;
                box-shadow: 0vh 0vh 10vh #f6e59f;
                text-shadow: 0 0 5px #f4f403,
                             0 0 25px #f4f403,
                             0 0 50px #f4f403,
                             0 0 100px #f4f403;
            }
            .getp{
                padding: 15px 30px;
                color: #222;
                letter-spacing: 4px;
                text-decoration: none;
                font-size: 30px;
                background: #e2b1d0;
                border: none;
                border-radius: 1vh;
                display: flex;
                position:absolute;
                bottom:4vh; 
                width: 12vw;
                height: 9vh;   
                align-items:center;
                justify-content:center;
                font-weight:bold;  
                cursor: pointer;
                text-transform:uppercase;
                transition:0.5s;
            }
            .getp:hover{
                color: #fff;
                background: #e2b1d0;
                box-shadow: 0vh 0vh 10vh #e2b1d0;
                text-shadow: 0 0 5px #f403c8;
                             0 0 25px #f403c8;
                             0 0 50px #f403c8;
                             0 0 100px #f403c8;
            }
            .getf{
                padding: 15px 30px;
                color: #222;
                letter-spacing: 4px;
                text-decoration: none;
                font-size: 30px;
                background: #c4f9ec;
                border: none;
                border-radius: 1vh;
                display: flex;
                position:absolute;
                bottom:4vh; 
                width: 12vw;
                height: 9vh;   
                align-items:center;
                justify-content:center;
                font-weight:bold;  
                cursor: pointer;
                text-transform:uppercase;
                transition:0.5s;
            }
            .getf:hover{
                color: #fff;
                background: #c4f9ec;
                box-shadow: 0vh 0vh 10vh #c4f9ec;
                text-shadow: 0 0 5px #03e9f4;
                             0 0 25px #03e9f4;
                             0 0 50px #03e9f4;
                             0 0 100px #03e9f4;
            }
        </style>
    </head>
    <body>
        <?php include 'localhost.php'; ?>
        <div class="menu">
            <img src="Webimage/fivegirls.png" class="fivegirl" alt="welcome photo" width="75%" height="10%">
            <div class="link-top"></div>
            <div class="menubtn">
                <div class="teamother">
                    <img src="Webimage/home_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_home()">Home</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/history_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_history()">History</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/favoritesongs_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn"  onclick="go_to_favorite()">Favorite</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/trendind_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_trending()">Trending</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/upgrade_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" id="now" onclick="go_to_upgrade()">Upgrade</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/artists_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_artists()">Artists</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/album_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_album()">Album</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/style_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_style()">Style</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/setting.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_setting()">Setting</button>
                </div>
            </div>
            <div class="musicplayer">
                <button class="cd" onclick="go_to_song()">
                    <img src="Webimage/cd_btn.PNG"  width="70%" alt="cd" >
                </button>
                <div class="SongName">
                    <h4  id="songName">Song Name</h4>
                </div>
                <div class="ArtistName">
                    <h6  id="artistName">Artist Name</h6>
                </div>
                <script>
                    document.addEventListener("DOMContentLoaded", function () {
                        checkTextLength();
                    });

                    function checkTextLength() {
                        var songNameElement = document.getElementById("songName");
                        var artistNameElement = document.getElementById("artistName");

                        if (songNameElement.scrollWidth > songNameElement.clientWidth) {
                            songNameElement.classList.add("marquee");
                        }

                        if (artistNameElement.scrollWidth > artistNameElement.clientWidth) {
                            artistNameElement.classList.add("marquee");
                        }
                    }
                </script>
                <div class="controlpannel">
                    <button class="controlbtn"><img src="Webimage/backsong_btn.PNG"   width="70%"></button>
                    <button class="controlbtn" onclick="toggleImage()"><img src="Webimage/play_btn.PNG"  width="70%" id="cdImage"></button>
                    <button class="controlbtn"><img src="Webimage/nextsong_btn.PNG"  width="70%"></button>
                </div>
            </div>
        </div>
        <div class="searchbar">
            <div class="searchteam">
                <img src="Webimage/search_icon.PNG" class="search" alt="homeicon" width="7%" height="200%">
                <input type="text" placeholder="Search for songs"  id="textInput" name="search" autocomplete="off">
                <button class="micro_btn" onclick="startSpeechRecognition()"><img src="Webimage/microphone _icon.PNG"  width="110%"></button>
            </div>
            <div class="name">
                <h4 class="Username"><?php echo htmlspecialchars($nameuser); ?></h4>
            </div>
                <?php
                    // 讀取性別
                    $gender = isset($_SESSION['gender']) ? $_SESSION['gender'] : '';

                    // 根據性別顯示不同的圖示
                    if ($gender === 'male') {
                        echo '<img class="sex" src="Webimage/boy_icon.png" alt="Male Icon" width="5%" >';
                    } elseif ($gender === 'female') {
                        echo '<img class="sex" src="Webimage/girl_icon.png" alt="Female Icon" width="5%" >';
                    } else {
                        // 預設為一般圖示
                        echo '<img class="sex" src="Webimage/othersex_icon.png" alt="Default Icon" width="5%" >';
                    }
                ?>
            </div>
        </div>
        <div class="change">
            <h3 class="title">LOVAN UPGRADE</h3>
            <div class="upgread_group">
                
                <div class="upgread_inside_indiv">
                    <h3 class="comp">LOVAN</h3>
                    <h4 class="type">Individual</h4>
                    <div class="linkupgrade"></div>
                    <div class="content">
                        <li>One account
                        <li>Cancel anytime
                    </div>
                    <h4 class="price">NT$ 150 /month</h4>
                    <button class="get">Get</button>
                </div>
                <div class="upgread_inside_stu">
                    <h3 class="comp">LOVAN</h3>
                    <h4 class="type">Student</h4>
                    <div class="linkupgrade"></div>
                    <div class="content">
                        <li>Have student <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;qualification
                        <li>Cancel anytime
                    </div>
                    <h4 class="price">NT$ 99 /month</h4>
                    <button class="getp">Get</button>
                </div>
                <div class="upgread_inside_fam">
                    <h3 class="comp">LOVAN</h3>
                    <h4 class="type">Family</h4>
                    <div class="linkupgrade"></div>
                    <div class="content">
                        <li>Share account <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;with your family
                        <li>Cancel anytime
                    </div>
                    <h4 class="price">NT$ 250 /month</h4>
                    <button class="getf">Get</button>
                </div>
            </div>
        </div>
    </body>
</html>