<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<body>
  <?php

    include 'localhost.php';

    $sql = "SELECT filename FROM photo";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      // output data of each row
      while($row = $result->fetch_assoc()) {
        $image=$row["filename"];
      echo "<img src=".$image." width=200 height=200>";
        
      }
    } else {
      echo "0 results";
    }
    $conn->close();

  
  ?>
</body>
</html>