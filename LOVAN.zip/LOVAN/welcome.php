<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="icon" href="Webimage/logo.png" type="image/x-icon"/>
    <title>Welcome to LOVAN</title>
    <style>
        @font-face {
            font-family: 'Arial Rounded MT Bold';
            src: url('LOVAN/Jack Armstrong.ttf') format('truetype'),
            url('LOVAN/Arial Rounded MT Bold.ttf') format('truetype');
        }

        * {
            margin: 0;
            padding: 0;
        }

        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #21201F;
            margin-top:1vh;
            overflow: hidden;
        }

        .welcome-container {
            display: flex;
            align-items: center;
        }

        #welcomeForm {
            margin-right: -4vw ;
            text-align: center;
        }

        h1 {
            color: #C499CF;
            margin-bottom: 3%;
            font-size: 10vh;
            font-weight: bold;
            font-style: oblique;
            text-align:left;
            margin-inline-start: 7vw;
            font-family: 'Jack Armstrong', sans-serif;
            
        }

        p {
            font-family: normal;
            font-size: 1.7vh;
            color: white;
            word-wrap: break-word;
            font-family: 'Jack Armstrong', sans-serif;
            text-align:left;
            margin-bottom:5%;
            margin-left:7vw;
            letter-spacing: 0.2vw;
        }

        button {
            padding: 2vh 2vw;
            color: inherit;
            text-transform: uppercase;
            letter-spacing: 0.2vw;
            font-weight: 590;
            text-decoration: none;
            font-size: 3vh;
            overflow: hidden;
            transition: 0.2s;
            background: white;
            border: none;
            border-radius: 0.2vw;
            margin-inline-start: -14vw;
            font-family: 'Jack Armstrong', sans-serif;
            margin-right: 1.2vw;
        }

        button:hover {
            color: white;
            background: #C499CF;
            box-shadow: 0 0 1vw #C499CF, 0 0 3vw #C499CF, 0 0 5vw #C499CF;
            transition-delay: 0.1s;
        }
        #welcomeForm-R{
            margin-right:7vw;

        }
    </style>
</head>

<body>
<?php include 'localhost.php'; ?>
    <div class="welcome-container">
        <div id="welcomeForm" class="welcome">
            <form id="welcomeForm-l" action="login.php" method="POST">
                <h1>LOVAN MUSIC</h1>
                <p>Introducing LOVAN, a new music streaming platform developed <br>
                and founded by five members. The name draws inspiration from <br>
                a medication used to treat anxiety and depression, aiming to build<br>
                a bridge to people's hearts through music. Whether you're<br>
                navigating the hustle and bustle of the day, immersed in <br>
                passionate love, or facing late-night emo moments during life's <br>
                life's challenges, LOVAN strives to provide resonant music for<br>
                every moment. Transform unexpressed emotions into heartfelt <br>
                melodies, reminding yourself, even in a challenging world, <br>
                you deserve to live beautifully! As the world kisses me with pain, <br>
                I respond with a song! <br><br>
                Now, join us in stepping onto the bridge built by LOVAN, embarking <br>
                on a journey to discover your unique musical experience!</p>
                <button type="submit" name="getinButton">GET IN</button>
                <img src="Webimage/fivegirls.png" alt="welcome photo" width="35%" height="35%">
            </form>
        </div>
        <form id="welcomeForm-R" method="POST">
            <img src="Webimage/welcomeicon.png" alt="welcome photo" width="100%" height="100%" >
        </form>
    </div>

</body>

</html>
