<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="icon" href="Webimage/logo.png" type="image/x-icon"/>
    <title>Style</title>
</head>

<body>
    style
</body>

</html>
