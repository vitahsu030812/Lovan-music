<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="Webimage/logo.png" type="image/x-icon"/>
    <title>Login to LOVAN</title>
    <style>
        @font-face {
            font-family: 'Jack Armstrong';
            src: url('LOVAN/Jack Armstrong.ttf') format('truetype'),
            url('LOVAN/Arial Rounded MT Bold.ttf') format('truetype');
        }

        * {
            margin: 0;
            padding: 0;
            font-family: 'Jack Armstrong';
        }
        body {
            height: 100%;
            background-image: url(Webimage/loginbackground.jpg);
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            background-size: cover;
        }
        .link-top {
            width: 100%;
            height: 1vh;
            border-top: solid white 0.3vh;
            justify-content: center;
            margin-top: 2vh;
            margin-bottom:6vh;
        }
        .link-bottom {
            width: 100%;
            height: 1vh;
            border-top: solid white 0.3vh;
            justify-content: center;
            margin-bottom: -10vh;
            margin-left: 1vw;
        }
        section {
            justify-content: center;
            align-items: center;
            display: flex;
            margin-top: 6vh;
        }
        .form-box {
            position: relative;
            width: 20vw;
            height: 55vh;
            background: none;
            border-radius: 3.75vh;
            display: flex;
            flex-direction: column;
            justify-content:center;
            align-items: center;
            padding: 6.25vh;
            box-shadow:0 0 2vw white;
            vertical-align: middle;
            margin-top: 10vh;
        }
        h2 {
            font-size: 1.5vw;
            color: #adb8ed;
            text-align: center;
            margin-top: -30vh;
        }
        .inputbox {
            width: 20vw;
            height: auto;
            padding: 0;
            border-radius: 0.5vh;
            margin-top: 1vh;
            margin-left: 0.625vw;
            margin-bottom: 8vh;
            justify-content: center;
        }
        .inputbox input {
            width:95%;
            background: transparent;
            color: #e7d292;
            font-size: 0.8vw;
            outline: none;
            padding:1vh;
            border-radius: 1vh;
            border: 0.15vw solid #fff;
            font-family: 'Arial Rounded MT Bold', sans-serif;
        }
        h3 {
            font-size: 1.5vw;
            color: white;
            text-align: left;
            margin-left: 1.25vw;
            margin-top: -5vh;
        }
        .forget {
            font-size: 0.7vw;
            color: white;
            text-align: right;
            margin-right: -1vw;
            margin-bottom: 1vh;
        }
        p {
            font-size: 0.8vw;
            color: white;
            text-align: center;
            margin-bottom: -30vh;
            margin-top: 5vh;
        }
        a {
            color: white;
            font-size: 0.8vw;
        }
        .btnlogin {
            padding: 2.1vh 1.3vw;
            color: inherit;
            text-transform: uppercase;
            letter-spacing: 0.25vw;
            text-decoration: none;
            font-size: 1.5vw;
            overflow: hidden;
            transition: 0.2s;
            background: #adb8ed;
            border: none;
            align-items: center;
            border-radius: 0.8vh;
            margin-top: 12vh;
            margin-left: 6.5vw;
            display: flex;
            justify-content: center;
        }

        .btnlogin:hover {
            color: #adb8ed;
            background: none;
            box-shadow: 0 0 1vw #adb8ed, 0 0 1vw #adb8ed;
            transition-delay: 0.1s;
        }
        .logo {
            position: absolute;
            top: 3vh;
            left: 2vw;
        }
        .back {
            position: absolute;
            top: 5vh;
            left: 6.5vw;
            font-size: 1vw;
            background: none;
            border: none;
            color: white;
            margin: 0;
            text-decoration: none;
        }

        .forgetpwd {
            position: relative;
            margin: auto;
            display: none;
            margin-top: 15vh;
            padding: 5vh;
            width: 20vw;
            height: 55vh;
            z-index: 2;
            position: fixed;
            top: 2.3vh;
            left: 37.8vw;
            box-shadow: 0.3vw 0.2vw 0.3vw 0.2vw darkgrey;
            border-radius: 3vh;
        }

        .forgetpwd::before {
            content: "";
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background-image: url(Webimage/forgetpasswordpng.PNG);
            background-size: cover;
            background-position: center; /* 或者根据需要调整位置 */
            /*transform: scale(0.5); /* 将背景图像缩小为原始大小的一半 */
            z-index: -1;
            border-radius: 3vh;
        }

        .btnsend {
            text-align: center;
            padding: 2.3vh 2.3vw;
            color: none;
            text-transform: uppercase;
            letter-spacing: 0.5vw;
            text-decoration: none;
            font-size: 1.5vw;
            overflow: hidden;
            transition: 0.2s;
            background: #57dcae;
            border: none;
            border-radius: 0.35vw;
            margin-top: 1vh;
            margin: 1vh auto; 
            display: block;
        }

        .btnsend:hover {
            color: #57dcae;
            background: none;
            box-shadow: 0 0 2.5vw #57dcae, 0 0 10vw #57dcae;
            transition-delay: 0.1s;
        }

        .fpwd {
            font-size: 2vw;
            color: #57dcae;
            line-height: 1.3;
            margin-top: 0;
            margin-bottom: 3vh;
        }

        .fpwda {
            font-size: 1vw;
            color: white;
            margin-top: 2vh;
            margin-left: 2vw;
            margin-right: 2vw;
        }

        .fpwdt {
            font-size: 1.5vw;
            color: white;
            text-align: left;
            margin-left: 1vw;
            margin-top: 1vh;
            margin-bottom: 1vh;
        }

        .fpwdinputbox {
            width: 18vw;
            height: 3.5vh;
            padding: 0vw;
            border-radius: 0.5vh;
            border: mone;
            margin-top: 2vh;
            margin-left: 0.8vw;
            margin-bottom: 7vh;
            justify-content: center;
        }
        .fpwdinputbox input {
            width: 100%;
            background: transparent;
            color: #e7d292;
            padding:1vh;
            font-size: 0.8vw;
            outline: none;
            border-radius: 1vh;
            border: 0.15vw solid #fff;
            font-family: 'Arial Rounded MT Bold', sans-serif;
        }

        .link {
            width: 22vw;
            height: 1vh;
            border-top: solid white 0.3vh;
            justify-content: center;
            margin-top: 1vh;
            margin-bottom: 1.5vh;
            margin-left: -0.7vw;
        }

        .fpwdlink {
            width: 22vw;
            height: 1vh;
            border-top: solid white 0.3vh;
            justify-content: center;
            margin-top: 0.5vh;
            margin-bottom: 1.5vh;
            margin-left: -0.7vw;
        }
    </style>
    <script>
        function show() {
            var show_part = document.querySelector('.forgetpwd');
            show_part.style.display = 'block';
        }
    </script>
</head>
<body>
    <?php include 'localhost.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.all.min.js"></script>
    <div>
        <a href="welcome.php"><img src="Webimage/logowhite.png" width=50cm height=50cm class="logo"></a>
        <a class="back" href="welcome.php">LOVAN MUSIC</a>
    </div>
    <section>
        <div class="form-box">
            <div class="form-vlaue" >
                <h2>Welcome back</h2>
                <div class="link-top"></div>
                <form action="loginenter.php" method="POST">
                    <h3>Email</h3>
                    <div class="inputbox">
                        <input type="email" placeholder="@gmail.com" id="loginEmail" name="loginEmail" required>
                    </div>
                    <h3>Password</h3>
                    <div class="inputbox">
                        <input type="password" id="loginPassword" name="loginPassword" required>
                    </div>
                    <div class="forget">
                        <label>
                            <a href="javascript:void(0);" onclick="show()">Forget Password</a>
                        </label>
                    </div>
                    <div class="link-bottom"></div>
                    <button type="submit" class="btnlogin">LOG IN</button>
                </form>
                <div class="register">
                    <p>Don't have an account?&emsp;<a href="register.php">sign up</a></p>
                </div>
            </div>
        </div>
        <form action="forgetinsert.php" method="POST">
            <div class="forgetpwd">
                <div class="form-vlaue">
                    <h2 class="fpwd">forget password</h2>
                    <div class="link"></div>
                    <form>
                        <h3 class="fpwdt">Email</h3>
                        <div class="fpwdinputbox">
                            <input type="email" placeholder="@gmail.com" id="forgetemail" name="forgetemail" required>
                        </div>
                        <div class="fpwdlink"></div>
                        <button type="submit" class="btnsend">send</button>
                    </form>
                    <div class="fpwda">
                        <a href="login.php">Login</a>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;
                        <a href="register.php">signup</a>
                    </div>
                </div>
            </div>
        </form>
    </section>
</body>
</html>
