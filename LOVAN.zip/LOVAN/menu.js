/*語音麥克風*/
function startSpeechRecognition() {
    // 检查浏览器是否支持Web Speech API
    if ('webkitSpeechRecognition' in window) {
        // 创建语音识别对象
        var recognition = new webkitSpeechRecognition();

        // 设置语言为中文（可以根据需要更改语言）
        recognition.lang = 'zh-CN';

        // 开始语音识别
        recognition.start();

        // 当识别到语音时触发
        recognition.onresult = function(event) {
            // 获取识别到的文本
            var transcript = event.results[0][0].transcript;

            // 将文本放入输入框
            document.getElementById('textInput').value = transcript;
        };

        // 当语音识别结束时触发
        recognition.onend = function() {
            // 可以在这里添加一些结束时的逻辑
        };
    } else {
        alert('抱歉，您的浏览器不支持语音识别功能。');
    }
}

/*頁面跳轉連動*/
function go_to_home() {
    window.location.href = "home.php";
}
function go_to_history() {
    window.location.href = "history.php";
}
function go_to_favorite() {
    window.location.href = "favorite.php";
}
function go_to_trending() {
    window.location.href = "trending.php";
}
function go_to_upgrade() {
    window.location.href = "upgrade.php";
}
function go_to_artists() {
    window.location.href = "artists.php";
}
function go_to_album() {
    window.location.href = "album.php";
}
function go_to_style() {
    window.location.href = "style.php";
}
function go_to_setting() {
    window.location.href = "setting.php";
}
function go_to_song() {
    window.location.href = "song.php";
}

/*頁面跳轉連動*/

/*暫停播放鍵*/
var isPlaying = localStorage.getItem('isPlaying') === 'true';
// 更新按鈕狀態
function updateButtonState() {
    var cdImage = document.getElementById('cdImage');         
    if (isPlaying) {
        cdImage.src = 'Webimage/pause_btn.PNG';
        scrollInterval = setInterval(scrollLyrics, 1000);
    } else {
        cdImage.src = 'Webimage/play_btn.PNG'; 
        clearInterval(scrollInterval); // 清除滾動間隔 
    } 
}
// 點擊按鈕時觸發
function toggleImage() {
    isPlaying = !isPlaying;
    // 將狀態存入 localStorage
    localStorage.setItem('isPlaying', isPlaying);
    updateButtonState();
}
// 在每個頁面加載時調用以保持按鈕狀態的一致性
window.onload = updateButtonState;
/*暫停播放鍵*/

/*愛心按紐*/
var ImageChanged = false;
function like(button) {
    var btnFavorite = button.querySelector('img');
    if (ImageChanged) {
        btnFavorite.src = 'Webimage/btn_favorite1.PNG';  // 切換回原始圖片
    } else {
        btnFavorite.src = 'Webimage/btn_favorite2.PNG';  // 切換到新圖片
    }

    ImageChanged = !ImageChanged;  // 切換狀態
}