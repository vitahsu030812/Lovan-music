<?php
session_start();

// 检查用户是否已登录
if (!isset($_SESSION["email"])) {
    // 用户未登录，重定向到登录页面
    header("Location: login.php");
    exit();
}

// 获取用户信息
$email = $_SESSION["email"];
$nameuser = $_SESSION["nameuser"];
$gender = $_SESSION["gender"];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="icon" href="Webimage/logo.png" type="image/x-icon"/>
        <title>Album</title>
        <script src="menu.js"></script>
        <style>
            @font-face {
                font-family: 'Arial Rounded MT Bold';
                src: url('LOVAN/Arial Rounded MT Bold.ttf') format('truetype');
            }

            * {
                margin: 0;
                padding:1vh;
                
            }
            body {
                height: 100vh;
                width: 100vh;
                display: flex;
                overflow: hidden;
                background-image: linear-gradient(90deg, rgb(98,67,126) , rgb(98,67,126) ,rgb(62,50,69) ,rgb(32,33,31) , rgb(32,33,31) , rgb(32,33,31) ,rgb(32,33,31));
                background-repeat: no-repeat;
            }   
            .menu{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:2vh;  margin:auto; 
                width: 35vh;
                height: 90vh;
                border-radius: 5vh;
                align-items: center;                
                padding: 1vh;
                padding-top: 3vh;
                backdrop-filter: blur(15px);
                background:rgba(255,255,255,0.05);
                margin-left:5vh;
                margin-top: 2.5vh;
            }
            
            .fivegirl{
                display: flex;
                position:absolute; right:0.3vh; left:0;  margin:auto; 
            }

            .link-top {
                width: 70%;
                border-top: solid white 2px;
                margin-top: 5vh;
                display: flex;
                position:absolute; top:13vh; right:0; left:0;  margin:auto; 

            }
            .menubtn{
                display: flex;
                flex-direction: column;
                position:absolute;  top:13vh; left:5vh; 
            }
            .teamother{
                margin-bottom: -2vh;
            }
            .teambtn{
                color: none;
                height: 3.5vh;
                letter-spacing: 4px;
                text-decoration: none;
                font-size: 15px;
                transition: 0.2s;
                background: none;
                border-color: transparent;
                border-radius: 5px;
                color: white;
                font-weight:bold;
                padding: 0vh 0vh;
                border-color: none;
                
            }
            button:hover {
                color: #e7d292;
                background: none;
            }
            #now{
                color: #e7d292;
            }
            .icon{
                margin-left: -2vh;
            }
            
            .musicplayer{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 3vh; right:0; left:2vh;   
                width: 28vh;
                height: 30vh;
                border-radius: 1vh;
                align-items: center;            
                padding: 10vh;
                padding-top: 3vh;
                background: rgb(83,63,103);  
                margin-left:1.5vh;
                margin-top: 1vh;
                box-shadow:0 0 1vh white;
                justify-content: center;
                flex-wrap:center;   
                overflow: hidden; 
            }
            .SongName{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 11vh; right:0; left:2.7vw;   
                width: 8vw;
                height: 5vh;   
                background: none;  
                justify-items: center;
                flex-wrap:center;   
                overflow: hidden;
                text-align: center;
                margin:0;
                padding:0;
                text-justify:center;
            }
            .ArtistName{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 8vh; right:0; left:1.63vw;   
                width: 10vw;
                height: 4vh;   
                background: none;  
                justify-items: center;
                flex-wrap:center;   
                overflow: hidden;
                text-align: center;
                text-justify:center;
                margin:0;
                padding:0;

                
            }
            .SongName h4 {
                color: white;
                text-align: center;
                white-space: nowrap;
                text-overflow: ellipsis;
                margin: 0;
            }

            .ArtistName h6 {
                color: white;
                text-align: center;
                white-space: nowrap;
                text-overflow: ellipsis;
                margin: 0;
            }
            .marquee {
                animation: marquee 25s linear infinite;
            }
            @keyframes marquee {
                0% {
                    transform: translateX(0%);
                }
                100% {
                    transform: translateX(-100%);
                }
            }
            .cd{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                display: flex;
                position:absolute; top:0vh; left:7vh;  margin:auto;
            }
            .cd:hover{
                background-color: none;
            }
            .cd.clicked img {
                content: url('Webimage/pause_btn.PNG');
            }
            
            .controlpannel{
                display: flex;
                position:absolute; top:21vh; left:2vh;
            }
            .controlbtn{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
            }
            .searchbar{
                display: flex;
                position:absolute; top:5.5vh; right:0; left:23vw;  margin:auto; 
            }
            .searchteam{
                display: flex;
                position:absolute; 
                width: 60vw;
                height: 7vh;
                border-radius: 2vh;
                align-items: top;            
                padding: 2vh;
                background: rgba(71,53,90,50%);
                justify-content: left;
                backdrop-filter: blur(15px);
                margin-top: 0vh;
            }
            .search{
                margin-left: -0.5vw;
                margin-top:-1.5vh; 
            }
            
            input{
                width: 100%;
                background: transparent;
                color:white;
                padding: 10px 20px;
                font-size: 18px;
                outline: none;
                border: none;
                font-weight:bold;
                margin-left:-1.5vw;
                font-family: 'Arial Rounded MT Bold', sans-serif;
                 
            }
            
            .micro_btn{
                display: flex;
                position:absolute; top:0vh; right:0; left:56vw;  margin:auto; 
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                flex-wrap: left;
                
            }
            .name{
                display: flex;
                position: absolute;
                top: -12.5vh;
                right: 0;
                left: 60vw;
                font-weight:bold;
            }
            .Username{
                color: white;
                align-items: center;
                display: flex;
                position:absolute; top:15vh;   margin:auto;
                text-transform:capitalize;
            }
            .sex{
                display: flex;
                position: absolute;
                top: 2vh;
                right: 0;
                left: 67vw;
            }
            .change{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:15vw; top:15vh; margin:auto; 
                width: 70vw;
                height: 80vh;
                align-items: center;                
                padding: 1vh;
                background:none;
            }
            .up{
                display: flex;
                flex-direction: row;
                border:none;
                width:100%;
                height:75%;
            }
            .left{
                border:none;
                width:38%;
                height:100%;
                padding:1vh;
                align-items: center; 
            }
            .left img{
                border-radius:3vh;
                width:100%;
            } 
            .right{
                border:none;
                width:62%;
                height:100%;
                padding:0;
                padding-top:1vh;
            }
            .down{
                border:none;
                width:100%;
                height:25%;
                padding:0;
                padding-left:1vw;
            }
            .right table{
                display:flex;
                border:none;
                width:100%;
                height:100%;
                color:white;
                padding:0;
                margin:0;
            }
            tr, td {
                border: none;
                padding:0;
                margin:0;
                border-collapse: collapse;
                 /* 单元格边框 */
            }
            .like{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
            }
            td:nth-child(1){
                width: 10%;
                text-align:end;
                padding:3vh;
            }
            td:nth-child(2){
                width: 75%;
                overflow:hidden;
            }
            td:nth-child(3){
                width: 10%;
            }
            tr:hover{
                background-color:rgba(255, 255, 255, 10%);
                backdrop-filter:blur(5px);
            }
            tr:hover td:nth-child(1){
                content: url('Webimage/LOVAN.PNG');
                width:100%;
                margin-top:1vh;
                padding:2vh;
            }
            .tsn{
                width:26vw;
                font-weight:bold;
                font-size:16px;
                white-space: nowrap;
            }
            #singer{
                font-size:12px;
                white-space: nowrap;
                width:25vw;
            }
            .down h3{
                margin:1vh;
                color:white;
                font-weight:bold;
                line-height:0.8;
                white-space: nowrap;
                letter-spacing:0.1vh;
            }
            .down h6{
                margin-left:0.5vw;
                color:rgba(255,255,255,60%);
                font-weight:bold;
                line-height:0.3;
                white-space: nowrap;
            }
            .btn_right{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                width:10vh;
                position:absolute;  right:1vw; bottom:5vh;
            }
            .btn_left{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                width:10vh;
                position:absolute;  right:6vw; bottom:5vh;
            }
        </style>
    </head>
    <body>
        <?php include 'localhost.php'; ?>
        <div class="menu">
            <img src="Webimage/fivegirls.png" class="fivegirl" alt="welcome photo" width="75%" height="10%">
            <div class="link-top"></div>
            <div class="menubtn">
                <div class="teamother">
                    <img src="Webimage/home_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_home()">Home</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/history_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_history()">History</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/favoritesongs_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn"  onclick="go_to_favorite()">Favorite</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/trendind_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_trending()">Trending</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/upgrade_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn"  onclick="go_to_upgrade()">Upgrade</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/artists_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_artists()">Artists</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/album_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" id="now" onclick="go_to_album()">Album</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/style_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_style()">Style</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/setting.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_setting()">Setting</button>
                </div>
            </div>
            <div class="musicplayer">
                <button class="cd" onclick="go_to_song()">
                    <img src="Webimage/cd_btn.PNG"  width="70%" alt="cd" >
                </button>
                <div class="SongName">
                    <h4  id="songName">Song Name</h4>
                </div>
                <div class="ArtistName">
                    <h6  id="artistName">Artist Name</h6>
                </div>
                <script>
                    document.addEventListener("DOMContentLoaded", function () {
                        checkTextLength();
                    });

                    function checkTextLength() {
                        var songNameElement = document.getElementById("songName");
                        var artistNameElement = document.getElementById("artistName");

                        if (songNameElement.scrollWidth > songNameElement.clientWidth) {
                            songNameElement.classList.add("marquee");
                        }

                        if (artistNameElement.scrollWidth > artistNameElement.clientWidth) {
                            artistNameElement.classList.add("marquee");
                        }

                    }

                </script>
                <div class="controlpannel">
                    <button class="controlbtn"><img src="Webimage/backsong_btn.PNG"   width="70%"></button>
                    <button class="controlbtn" onclick="toggleImage()"><img src="Webimage/play_btn.PNG"  width="70%" id="cdImage"></button>
                    <button class="controlbtn"><img src="Webimage/nextsong_btn.PNG"  width="70%"></button>
                </div>
            </div>
        </div>
        <div class="searchbar">
            <div class="searchteam">
                <img src="Webimage/search_icon.PNG" class="search" alt="homeicon" width="7%" height="200%">
                <input type="text" placeholder="Search for songs"  id="textInput" name="search" autocomplete="off">
                <button class="micro_btn" onclick="startSpeechRecognition()"><img src="Webimage/microphone _icon.PNG"  width="110%"></button>
            </div>
            <div class="name">
                <h4 class="Username"><?php echo htmlspecialchars($nameuser); ?></h4>
            </div>
                <?php
                    // 讀取性別
                    $gender = isset($_SESSION['gender']) ? $_SESSION['gender'] : '';

                    // 根據性別顯示不同的圖示
                    if ($gender === 'male') {
                        echo '<img class="sex" src="Webimage/boy_icon.png" alt="Male Icon" width="5%" >';
                    } elseif ($gender === 'female') {
                        echo '<img class="sex" src="Webimage/girl_icon.png" alt="Female Icon" width="5%" >';
                    } else {
                        // 預設為一般圖示
                        echo '<img class="sex" src="Webimage/othersex_icon.png" alt="Default Icon" width="5%" >';
                    }
                ?>
            </div>
        </div>
        <div class="change">
            <div class="up">
                <div class="left">
                    <img src="Webimage/album.PNG">
                </div>
                <div class="right">
                    <table id="page1">
                        <tr>
                            <td>1</td>
                            <td class="songn" ><div class="tsn" id="songname">God of Musicssssssssssssssss</div><div  id="singer">Seventeen123456sssssssssssssssssssssssssssssssssss</div></td>
                            <td><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td class="songn" ><div class="tsn" id="songname">God of Musicsssssssssssssssssssssssss</div><div  id="singer">Seventeen123456sssssssssssssssss</div></td>
                            <td><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td class="songn" ><div class="tsn" id="songname">God of Musicsssssssssssssssssssssssss</div><div  id="singer">Seventeen123456sssssssssssssssss</div></td>
                            <td><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td class="songn" ><div class="tsn" id="songname">God of Musicsssssssssssssssssssssssss</div><div  id="singer">Seventeen123456sssssssssssssssss</div></td>
                            <td><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td class="songn" ><div class="tsn" id="songname">God of Musicsssssssssssssssssssssssss</div><div  id="singer">Seventeen123456sssssssssssssssss</div></td>
                            <td><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                        </tr>
                    </table>
                    <table id="page2" style="display: none;">
                        <tr>
                            <td>6</td>
                            <td class="songn" ><div class="tsn" id="songname">God of Musicssssssssssssssss</div><div  id="singer">Seventeen123456sssssssssssssssssssssssssssssssssss</div></td>
                            <td><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                        </tr>
                        <tr>
                            <td>7</td>
                            <td class="songn" ><div class="tsn" id="songname">God of Musicsssssssssssssssssssssssss</div><div  id="singer">Seventeen123456sssssssssssssssss</div></td>
                            <td><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                        </tr>
                        <tr>
                            <td>8</td>
                            <td class="songn" ><div class="tsn" id="songname">God of Musicsssssssssssssssssssssssss</div><div  id="singer">Seventeen123456sssssssssssssssss</div></td>
                            <td><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                        </tr>
                        <tr>
                            <td>9</td>
                            <td class="songn" ><div class="tsn" id="songname">God of Musicsssssssssssssssssssssssss</div><div  id="singer">Seventeen123456sssssssssssssssss</div></td>
                            <td><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                        </tr>
                        <tr>
                            <td>10</td>
                            <td class="songn" ><div class="tsn" id="songname">God of Musicsssssssssssssssssssssssss</div><div  id="singer">Seventeen123456sssssssssssssssss</div></td>
                            <td><button class="like" onclick="like(this)"><img src="Webimage/btn_favorite1.PNG" width="70%"></button></td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="down">
                <h3>SEVENTEEN 11th Mini Album</h3>
                <h3>' SEVENTEEN HEAVEN '</h3>
                <h6>EP．SEVENTEEN．2023</h6>
                <button class="btn_left" onclick="prevPage()"><img src="Webimage/btn_left.PNG" width="100%"></button>
                <button class="btn_right" onclick="nextPage()"><img src="Webimage/btn_right.PNG" width="100%"></button>
            </div>
            <script>
                var currentPage = 1;

                function changePage(pageNumber) {
                    document.getElementById('page' + currentPage).style.display = 'none';
                    document.getElementById('page' + pageNumber).style.display = 'flex';
                    currentPage = pageNumber;
                    applyMarqueeEffect();
                }

                function prevPage() {
                    if (currentPage > 1) {
                        changePage(currentPage - 1);
                    }
                }

                function nextPage() {
                    if (currentPage < 2) {
                        changePage(currentPage + 1);
                    }
                }
            </script>
        </div>
    </body>
</html>