<?php
session_start();

// 检查用户是否已登录
if (!isset($_SESSION["email"])) {
    // 用户未登录，重定向到登录页面
    header("Location: login.php");
    exit();
}

// 获取用户信息
$email = $_SESSION["email"];
$nameuser = $_SESSION["nameuser"];
$gender = $_SESSION["gender"];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="icon" href="Webimage/logo.png" type="image/x-icon"/>
        <title>Artists</title>
        <script src="menu.js"></script>
        <style>
            @font-face {
            font-family: 'Arial Rounded MT Bold';
            src: url('LOVAN/Arial Rounded MT Bold.ttf') format('truetype');
            }

            * {
                margin: 0;
                padding:1vh;
                
            }
            body {
                height: 100vh;
                width: 100vh;
                display: flex;
                overflow: hidden;
                background-image: linear-gradient(90deg, rgb(98,67,126) , rgb(98,67,126) ,rgb(62,50,69) ,rgb(32,33,31) , rgb(32,33,31) , rgb(32,33,31) ,rgb(32,33,31));
                background-repeat: no-repeat;
            }   
            .menu{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:2vh;  margin:auto; 
                width: 35vh;
                height: 90vh;
                border-radius: 5vh;
                align-items: center;                
                padding: 1vh;
                padding-top: 3vh;
                backdrop-filter: blur(15px);
                background:rgba(255,255,255,0.05);
                margin-left:5vh;
                margin-top: 2.5vh;
            }
            
            .fivegirl{
                display: flex;
                position:absolute; right:0.3vh; left:0;  margin:auto; 
            }

            .link-top {
                width: 70%;
                border-top: solid white 2px;
                margin-top: 5vh;
                display: flex;
                position:absolute; top:13vh; right:0; left:0;  margin:auto; 

            }
            .menubtn{
                display: flex;
                flex-direction: column;
                position:absolute;  top:13vh; left:5vh; 
            }
            .teamother{
                margin-bottom: -2vh;
            }
            .teambtn{
                color: none;
                height: 3.5vh;
                letter-spacing: 4px;
                text-decoration: none;
                font-size: 15px;
                transition: 0.2s;
                background: none;
                border-color: transparent;
                border-radius: 5px;
                color: white;
                font-weight:bold;
                padding: 0vh 0vh;
                border-color: none;
                
            }
            button:hover {
                color: #e7d292;
                background: none;
            }
            #now{
                color: #e7d292;
            }
            .icon{
                margin-left: -2vh;
            }
            
            .musicplayer{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 3vh; right:0; left:2vh;   
                width: 28vh;
                height: 30vh;
                border-radius: 1vh;
                align-items: center;            
                padding: 10vh;
                padding-top: 3vh;
                background: rgb(83,63,103);  
                margin-left:1.5vh;
                margin-top: 1vh;
                box-shadow:0 0 1vh white;
                justify-content: center;
                flex-wrap:center;   
                overflow: hidden; 
            }
            .SongName{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 11vh; right:0; left:2.7vw;   
                width: 8vw;
                height: 5vh;   
                background: none;  
                justify-items: center;
                flex-wrap:center;   
                overflow: hidden;
                text-align: center;
                margin:0;
                padding:0;
                text-justify:center;
            }
            .ArtistName{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 8vh; right:0; left:1.63vw;   
                width: 10vw;
                height: 4vh;   
                background: none;  
                justify-items: center;
                flex-wrap:center;   
                overflow: hidden;
                text-align: center;
                text-justify:center;
                margin:0;
                padding:0;

                
            }
            .SongName h4 {
                color: white;
                text-align: center;
                white-space: nowrap;
                text-overflow: ellipsis;
                margin: 0;
            }

            .ArtistName h6 {
                color: white;
                text-align: center;
                white-space: nowrap;
                text-overflow: ellipsis;
                margin: 0;
            }
            .marquee {
                animation: marquee 25s linear infinite;
            }
            @keyframes marquee {
                0% {
                    transform: translateX(0%);
                }
                100% {
                    transform: translateX(-100%);
                }
            }
            .cd{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                display: flex;
                position:absolute; top:0vh; left:7vh;  margin:auto;
            }
            .cd:hover{
                background-color: none;
            }
            .cd.clicked img {
                content: url('Webimage/pause_btn.PNG');
            }
            
            .controlpannel{
                display: flex;
                position:absolute; top:21vh; left:2vh;
            }
            .controlbtn{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
            }
            .searchbar{
                display: flex;
                position:absolute; top:5.5vh; right:0; left:23vw;  margin:auto; 
            }
            .searchteam{
                display: flex;
                position:absolute; 
                width: 60vw;
                height: 7vh;
                border-radius: 2vh;
                align-items: top;            
                padding: 2vh;
                background: rgba(71,53,90,50%);
                justify-content: left;
                backdrop-filter: blur(15px);
                margin-top: 0vh;
            }
            .search{
                margin-left: -0.5vw;
                margin-top:-1.5vh; 
            }
            
            input{
                width: 100%;
                background: transparent;
                color:white;
                padding: 10px 20px;
                font-size: 18px;
                outline: none;
                border: none;
                font-weight:bold;
                margin-left:-1.5vw;
                font-family: 'Arial Rounded MT Bold', sans-serif;
                 
            }
            
            .micro_btn{
                display: flex;
                position:absolute; top:0vh; right:0; left:56vw;  margin:auto; 
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                flex-wrap: left;
                
            }
            .name{
                display: flex;
                position: absolute;
                top: -12.5vh;
                right: 0;
                left: 60vw;
                font-weight:bold;
            }
            .Username{
                color: white;
                align-items: center;
                display: flex;
                position:absolute; top:15vh;   margin:auto;
                text-transform:capitalize;
            }
            .sex{
                display: flex;
                position: absolute;
                top: 2vh;
                right: 0;
                left: 67vw;
            }
            .change{
                display: flex;
                flex-direction:row;
                position:absolute;  right:0; left:15vw; top:15vh; margin:auto; 
                width: 70vw;
                height: 80vh;
                align-items: start;                
                padding: 1vh;
                background:none;
            }
            .singerlist{
                display: flex;
                flex-direction:column;
                height:100%;
                width:30%;
                overflow:auto;
                border:0px solid white;
            }
            .songlist{
                display: flex;
                flex-direction: column;
                height:100%;
                width:70%;
                overflow:auto;
                border:none;
            }
            .singerlist table{
                width:100%;
                border:none;
            }
            .singerlist tr,td{
                border:none;
            }
            .singerlist tr:hover{
                background-color:rgba(255, 255, 255, 10%);
                backdrop-filter:blur(5px);
            }
            .singerlist td:nth-child(1){
                width:25%;
                padding:0vh;
            }
            .singerlist td:nth-child(1) img{
                border-radius:10vh;
            }
            .singerlist td:nth-child(2){
                justify-content:center;
                width:70%;
                padding-left:0vw;
                padding-top:2vh;
                overflow:hidden;
            }
            .singerlist div{
                color:white;
                width:10vw;
            }
            .singerlist::-webkit-scrollbar {
                width: 0.3vw; /* 设置滚动条的宽度 */
            }

            .singerlist::-webkit-scrollbar-track {
                background-color: none; /* 设置滚动条轨道的背景色 */
            }

            .singerlist::-webkit-scrollbar-thumb {
                background-color: white; /* 设置滚动条滑块的颜色 */
                border-radius: 10vw; /* 设置滚动条滑块的圆角 */
            }

            .singerlist::-webkit-scrollbar-thumb:hover {
                background-color: #555; /* 鼠标悬停时滚动条滑块的颜色 */
            }
            .tittle{
                display: flex;
                flex-direction: row;
                width:100%;
                height:20%;
                border:none;
            }
            .photo{
                width:13%;
                height:100%;
                padding:0;
                border:none;
            }
            .photo img{
                border-radius:30vh;
                height:100%;
                margin:0;
            }
            .intro{
                width:88%;
                height:100%;
                overflow:auto;
                border:none;
                padding:2vh;
                padding-top:0;                
            }
            .intro::-webkit-scrollbar {
                width: 0vw; /* 设置滚动条的宽度 */
            }

            .intro::-webkit-scrollbar-track {
                background-color: none; /* 设置滚动条轨道的背景色 */
            }

            .intro::-webkit-scrollbar-thumb {
                background-color: none; /* 设置滚动条滑块的颜色 */
                border-radius: 10vw; /* 设置滚动条滑块的圆角 */
            }

            .intro::-webkit-scrollbar-thumb:hover {
                background-color: #555; /* 鼠标悬停时滚动条滑块的颜色 */
            }
            .intro h2{
                color:white;
                margin-top:2.5vh;
                font-weight:bold;
            }
            .intro p{
                color:white;
            }
            .list{
                width:100%;
                height:80%;
                border:none;
                overflow:auto;
            }
            .ilist{
                width:100%;
                height:auto;
                display: flex;
                flex-direction: row;
                flex-wrap : wrap;
                justify-content: flex-start;
            }
            .list table{
                border:none;
                width:50%;
                height:8vh;
            }
            .list table:hover{
                background-color:rgba(255, 255, 255, 10%);
                backdrop-filter:blur(5px);
            }
            .list td:nth-child(1){
                width:20%;
                padding:0vh;
            }
            .list td:nth-child(1) img{
                width:100%;
            }
            .list td:nth-child(2){
                width:80%;
                color:white;
                font-size:18px;
                padding:1vh;
            }
            .ilist td div{
                width:15vw;
                white-space: nowrap;
                overflow:hidden;
            }
            .list::-webkit-scrollbar {
                width: 0.3vw; /* 设置滚动条的宽度 */
            }

            .list::-webkit-scrollbar-track {
                background-color: none; /* 设置滚动条轨道的背景色 */
            }

            .list::-webkit-scrollbar-thumb {
                background-color: white; /* 设置滚动条滑块的颜色 */
                border-radius: 10vw; /* 设置滚动条滑块的圆角 */
            }

            .list::-webkit-scrollbar-thumb:hover {
                background-color: #555; /* 鼠标悬停时滚动条滑块的颜色 */
            }
        </style>
    </head>
    <body>
        <?php include 'localhost.php'; ?>
        <div class="menu">
            <img src="Webimage/fivegirls.png" class="fivegirl" alt="welcome photo" width="75%" height="10%">
            <div class="link-top"></div>
            <div class="menubtn">
                <div class="teamother">
                    <img src="Webimage/home_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_home()">Home</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/history_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_history()">History</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/favoritesongs_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn"  onclick="go_to_favorite()">Favorite</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/trendind_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_trending()">Trending</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/upgrade_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_upgrade()">Upgrade</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/artists_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" id="now" onclick="go_to_artists()">Artists</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/album_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_album()">Album</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/style_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_style()">Style</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/setting.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_setting()">Setting</button>
                </div>
            </div>
            <div class="musicplayer">
                <button class="cd" onclick="go_to_song()">
                    <img src="Webimage/cd_btn.PNG"  width="70%" alt="cd" >
                </button>
                <div class="SongName">
                    <h4  id="songName">Song Name</h4>
                </div>
                <div class="ArtistName">
                    <h6  id="artistName">Artist Name</h6>
                </div>
                <script>
                    document.addEventListener("DOMContentLoaded", function () {
                        checkTextLength();
                    });

                    function checkTextLength() {
                        var songNameElement = document.getElementById("songName");
                        var artistNameElement = document.getElementById("artistName");

                        if (songNameElement.scrollWidth > songNameElement.clientWidth) {
                            songNameElement.classList.add("marquee");
                        }

                        if (artistNameElement.scrollWidth > artistNameElement.clientWidth) {
                            artistNameElement.classList.add("marquee");
                        }
                    }
                </script>
                <div class="controlpannel">
                    <button class="controlbtn"><img src="Webimage/backsong_btn.PNG"   width="70%"></button>
                    <button class="controlbtn" onclick="toggleImage()"><img src="Webimage/play_btn.PNG"  width="70%" id="cdImage"></button>
                    <button class="controlbtn"><img src="Webimage/nextsong_btn.PNG"  width="70%"></button>
                </div>
            </div>
        </div>
        <div class="searchbar">
            <div class="searchteam">
                <img src="Webimage/search_icon.PNG" class="search" alt="homeicon" width="7%" height="200%">
                <input type="text" placeholder="Search for songs"  id="textInput" name="search" autocomplete="off">
                <button class="micro_btn" onclick="startSpeechRecognition()"><img src="Webimage/microphone _icon.PNG"  width="110%"></button>
            </div>
            <div class="name">
                <h4 class="Username"><?php echo htmlspecialchars($nameuser); ?></h4>
            </div>
                <?php
                    // 讀取性別
                    $gender = isset($_SESSION['gender']) ? $_SESSION['gender'] : '';

                    // 根據性別顯示不同的圖示
                    if ($gender === 'male') {
                        echo '<img class="sex" src="Webimage/boy_icon.png" alt="Male Icon" width="5%" >';
                    } elseif ($gender === 'female') {
                        echo '<img class="sex" src="Webimage/girl_icon.png" alt="Female Icon" width="5%" >';
                    } else {
                        // 預設為一般圖示
                        echo '<img class="sex" src="Webimage/othersex_icon.png" alt="Default Icon" width="5%" >';
                    }
                ?>
            </div>
        </div>
        <div class="change">
            <div class="singerlist">
                <table>
                    <tr>
                        <td><img src="Webimage/album.PNG" width="100%"></td>
                        <td><div >Seventeen<div></td>
                    </tr>
                    <tr>
                        <td><img src="Webimage/album.PNG" width="100%"></td>
                        <td><div>Seventeen<div></td>
                    </tr>
                    <tr>
                        <td><img src="Webimage/album.PNG" width="100%"></td>
                        <td><div>Seventeen<div></td>
                    </tr>
                    <tr>
                        <td><img src="Webimage/album.PNG" width="100%"></td>
                        <td><div>Seventeen<div></td>
                    </tr>
                    <tr>
                        <td><img src="Webimage/album.PNG" width="100%"></td>
                        <td><div>Seventeen<div></td>
                    </tr>
                    <tr>
                        <td><img src="Webimage/album.PNG" width="100%"></td>
                        <td><div>Seventeen<div></td>
                    </tr>
                    <tr>
                        <td><img src="Webimage/album.PNG" width="100%"></td>
                        <td><div>Seventeen<div></td>
                    </tr>
                    <tr>
                        <td><img src="Webimage/album.PNG" width="100%"></td>
                        <td><div>Seventeen<div></td>
                    </tr>
                </table>
            </div>
            <div class="songlist">
                <div class="tittle">
                    <div class="photo"><img src="Webimage/album.PNG"></div>
                    <div class="intro">
                        <h2>Artist Name</h2>
                        <p>"In the heart of the bustling city, where the neon lights paint the night sky with vibrant colors, lies a cozy cafe named 'Whimsical Brews.' This charming spot has become a haven for locals seeking a refuge from the daily grind. The aroma of freshly brewed coffee wafts through the air, accompanied by the soft hum of friendly chatter.</p>
                    </div>
                </div>
                <div class="list">
                    <div class="ilist">
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td><div>Fuck My Life</div></td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                        <table>
                            <tr>
                                <td><img src="Webimage/album.PNG"></td>
                                <td>Fuck My Life</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>