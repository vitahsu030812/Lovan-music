<?php
session_start();

// 检查用户是否已登录
if (!isset($_SESSION["email"])) {
    // 用户未登录，重定向到登录页面
    header("Location: login.php");
    exit();
}

// 获取用户信息
$email = $_SESSION["email"];
$nameuser = $_SESSION["nameuser"];
$gender = $_SESSION["gender"];
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="icon" href="Webimage/logo.png" type="image/x-icon"/>
        <title>LOVAN Music</title>
        <script src="menu.js"></script>
        <style>
            @font-face {
            font-family: 'Arial Rounded MT Bold';
            src: url('LOVAN/Arial Rounded MT Bold.ttf') format('truetype');
            }

            * {
                margin: 0;
                padding:1vh;
                
            }
            body {
                height: 100vh;
                width: 100vh;
                display: flex;
                overflow: hidden;
                background-image: linear-gradient(90deg, rgb(98,67,126) , rgb(98,67,126) ,rgb(62,50,69) ,rgb(32,33,31) , rgb(32,33,31) , rgb(32,33,31) ,rgb(32,33,31));
                background-repeat: no-repeat;
            }   
            .menu{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:2vh;  margin:auto; 
                width: 35vh;
                height: 90vh;
                border-radius: 5vh;
                align-items: center;                
                padding: 1vh;
                padding-top: 3vh;
                backdrop-filter: blur(15px);
                background:rgba(255,255,255,0.05);
                margin-left:5vh;
                margin-top: 2.5vh;
            }
            
            .fivegirl{
                display: flex;
                position:absolute; right:0.3vh; left:0;  margin:auto; 
            }

            .link-top {
                width: 70%;
                border-top: solid white 2px;
                margin-top: 5vh;
                display: flex;
                position:absolute; top:13vh; right:0; left:0;  margin:auto; 

            }
            .menubtn{
                display: flex;
                flex-direction: column;
                position:absolute;  top:13vh; left:5vh; 
            }
            .teamother{
                margin-bottom: -2vh;
            }
            .teambtn{
                color: none;
                height: 3.5vh;
                letter-spacing: 4px;
                text-decoration: none;
                font-size: 15px;
                transition: 0.2s;
                background: none;
                border-color: transparent;
                border-radius: 5px;
                color: white;
                font-weight:bold;
                padding: 0vh 0vh;
                border-color: none;
                
            }
            .teambtn:hover {
                color: #e7d292;
                background: none;
            }
            .icon{
                margin-left: -2vh;
            }
            
            .musicplayer{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 3vh; right:0; left:2vh;   
                width: 28vh;
                height: 30vh;
                border-radius: 1vh;
                align-items: center;            
                padding: 10vh;
                padding-top: 3vh;
                background: rgb(83,63,103);  
                margin-left:1.5vh;
                margin-top: 1vh;
                box-shadow:0 0 1vh white;
                justify-content: center;
                flex-wrap:center;   
                overflow: hidden; 
            }
            .SongName{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 11vh; right:0; left:2.7vw;   
                width: 8vw;
                height: 5vh;   
                background: none;  
                justify-items: center;
                flex-wrap:center;   
                overflow: hidden;
                text-align: center;
                margin:0;
                padding:0;
                text-justify:center;
            }
            .ArtistName{
                display: flex;
                flex-direction: column;
                position:absolute;  bottom: 8vh; right:0; left:1.63vw;   
                width: 10vw;
                height: 4vh;   
                background: none;  
                justify-items: center;
                flex-wrap:center;   
                overflow: hidden;
                text-align: center;
                text-justify:center;
                margin:0;
                padding:0;

                
            }
            .SongName h4 {
                color: white;
                text-align: center;
                white-space: nowrap;
                text-overflow: ellipsis;
                margin: 0;
            }

            .ArtistName h6 {
                color: white;
                text-align: center;
                white-space: nowrap;
                text-overflow: ellipsis;
                margin: 0;
            }
            .marquee {
                animation: marquee 25s linear infinite;
            }

            @keyframes marquee {
                0% {
                    transform: translateX(0%);
                }
                100% {
                    transform: translateX(-100%);
                }
            }
            .cd{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                display: flex;
                position:absolute; top:0vh; left:7vh;  margin:auto;
            }
            .cd:hover{
                background-color: none;
            }
            .cd.clicked img {
                content: url('Webimage/pause_btn.PNG');
            }
            
            .controlpannel{
                display: flex;
                position:absolute; top:21vh; left:2vh;
            }
            .controlbtn{
                color: none;
                overflow: hidden;
                background: none;
                border: none;
            }
            .searchbar{
                display: flex;
                position:absolute; top:5.5vh; right:0; left:23vw;  margin:auto; 
            }
            .searchteam{
                display: flex;
                position:absolute; 
                width: 60vw;
                height: 7vh;
                border-radius: 2vh;
                align-items: top;            
                padding: 2vh;
                background: rgba(71,53,90,50%);
                justify-content: left;
                backdrop-filter: blur(15px);
                margin-top: 0vh;
            }
            .search{
                margin-left: -0.5vw;
                margin-top:-1.5vh; 
            }
            
            input{
                width: 100%;
                background: transparent;
                color:white;
                padding: 10px 20px;
                font-size: 18px;
                outline: none;
                border: none;
                font-weight:bold;
                margin-left:-1.5vw;
                font-family: 'Arial Rounded MT Bold', sans-serif;
                 
            }
            
            .micro_btn{
                display: flex;
                position:absolute; top:0vh; right:0; left:56vw;  margin:auto; 
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                flex-wrap: left;
                
            }
            .micro_btn::before {
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.6);
                transform: scale(0);
                animation: ripple 0.6s linear;
            }
            @keyframes ripple {
                to {
                    transform: scale(4);
                    opacity: 0;
                }
            }
            .name{
                display: flex;
                position: absolute;
                top: -12.5vh;
                right: 0;
                left: 60vw;
                font-weight:bold;
            }
            .Username{
                color: white;
                align-items: center;
                display: flex;
                position:absolute; top:15vh;   margin:auto;
                text-transform:capitalize;
            }
            .recommend{
                display: flex;
                flex-direction: column;
                position:absolute;  right:0; left:20vw; top: 13vh; margin:auto; 
                width: 80vw;
                height: 40vh;
                border-radius: 5vh;
                align-items: left;                
                padding: 1vh;
                background:none;
                margin-left:5vh;
                margin-top: 2.5vh;
            }
            .foryou{
                color: white;
                font-weight:bold;
                margin-bottom:-2vh ;
                margin-top: -3vh;
            }
            .mainmusic_btn{
                width: 8vw;
                height: 13vh;
                background-size: cover; /* 确保背景图像覆盖整个按钮 */
                background-position: center; /* 将背景图像居中 */
                background-repeat: no-repeat; /* 防止背景图像重复 */
                border: none;
                overflow: hidden;
                position: relative;
                border-radius: 2vh;
                margin-left: 0.5vw;
                color: hsl(0, 0%, 90%);
                filter: brightness(1);
                text-align:center;

                h2{
                    font-size: 4rem;
                    letter-spacing: 2px;
                    text-transform: uppercase;
                    font-weight: 900;
                    transform: scale(2);
                    opacity: 0;
                    transition: 0.5s;
                }
                p{
                    font-size: 1.6rem;
                    padding-left: 2px;
                    transform: scale(1.2);
                    opacity: 0;
                    transition: 0.4s;
                }
                
            }
            .mainmusic{
                opacity: 1;
                backdrop-filter:blur(5px);
                transform: scale(1.1);
                color: rgba(255, 255, 255, 1);
                h2{
                    opacity: 0.8;
                    transform: scale(1);
                }

                p{
                    opacity: 0.6;
                    transform: scale(1);
                }
            }

            
            .groupmainmusic_btn{
                margin-left: 1vh;
            }
            .sex{
                display: flex;
                position: absolute;
                top: 2vh;
                right: 0;
                left: 67vw;
            }
            .setting_btn{
                display: flex;
                position:absolute; top:2vh; right:0vh; left:100vh;  margin:auto; 
                color: none;
                overflow: hidden;
                background: none;
                border: none;
                flex-wrap: left;
                margin-left:-9vh;
            }
            .style_btngroup{
                display: flex;
                flex-direction: column;
                position: absolute; left: 23vw; top:54vh;
                width: 15vw;
                height: 40vh;
                align-items: center;              
            }
            .style_btn{
                width: 12vw;
                height: 6vh;
                padding-top: 1vh;
                color: none;
                text-transform: uppercase;
                color: white;
                letter-spacing: 4px;
                text-decoration: none;
                font-size: 16px;
                overflow: hidden;
                transition: 0.2s;
                background: #525265;
                border: none;
                border-radius: 0.5vh;
                margin-inline-start: -50px;
                margin-top: 4vh;
                margin-left: 0.5vh;
                box-shadow:0vh 0vh 1vh white;
                border: 2px solid white;
                font-weight:bold;
                text-transform:capitalize;

            }
            .style_btn:hover{
                background: #9393ab;
                color: white;
            }
            
            .style_btnmore{
                width: 12vw;
                height: 6vh;
                padding: 10px 10px;
                padding-left: 2vw;
                color: none;
                text-transform: uppercase;
                color: white;
                letter-spacing: 4px;
                text-decoration: none;
                font-size: 16px;
                overflow: hidden;
                transition: 0.2s;
                background: none;
                border: none;
                border-radius: 0.5vh;
                margin-inline-start: -50px;
                margin-top: 2vh;
                margin-left: 0.5vh;
                font-weight:bold;
                text-transform:capitalize; 

            }
            .style_btnmore:hover{
                text-shadow: 0vh 0vh 3vh white;
                color: #e7d292;
            }
            .replay{
                display: flex;
                flex-direction: column;
                position: absolute;
                top: 60vh;
                right: 0;
                left: 39vw;
                width: 53vw;
                height: 33vh;
                bottom: 0;
                align-items: center;
                justify-self: end;
                background:none;
            }
            .slideshow-container {
                position: absolute;
                width: 110%; /* 設置最大寬度為容器的寬度 */
                height: 115%;
                bottom: 0vh;
                overflow: hidden;
            }

            /* 圖片樣式 */
            .slide {
                display:none;
                width: 110%;
                height: 110%;
            }

                /* 點樣式 */
            .dot {
                height: 5px;
                width: 5px;
                border-radius: 50%;
                background-color: white;
                display: inline-block;
                margin: 3px 10px;
            }

                /* 活動點樣式 */
            .active {
                background-color: #717171;
            }

            .slider {
                width: 100%;
                height: 100%;
                overflow: hidden;
                position: relative;
            }

            .slider-inner {
                width: 500%; /* 5張圖片，每張20%寬度 */
                height: 100%;
                display: flex;
            }

            .slide {
                flex: 0 0 20%;
            }

            .slide img {
                width: 100%; /* 5張圖片，每張20%寬度 */
                height: 100%;
                display: flex;
                transition: transform 0.5s ease-in-out;
            }

            .prev-btn,.next-btn {
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                background-color: none;
                color: rgba(255, 255, 255, 0.7);
                padding: 10px;
                cursor: pointer;
            }

            .prev-btn {
                left: 5.5vh;
            }

            .next-btn {
                right: 4vh;
            }
            .dot-container{
                display: flex;
                position:absolute; top:30vh; right:0vh; left:21vw;  margin:auto;
            }
        </style>
    </head>
    <body>
        <?php include 'localhost.php'; ?>
        <div class="menu">
            <img src="Webimage/fivegirls.png" class="fivegirl" alt="welcome photo" width="75%" height="10%">
            <div class="link-top"></div>
            <div class="menubtn">
                <div class="teamother">
                    <img src="Webimage/home_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_home()">Home</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/history_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_history()">History</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/favoritesongs_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_favorite()">Favorite</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/trendind_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_trending()">Trending</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/upgrade_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_upgrade()">Upgrade</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/artists_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_artists()">Artists</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/album_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_album()">Album</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/style_icon.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_style()">Style</button>
                </div>
                <div class="teamother">
                    <img src="Webimage/setting.PNG" class="icon" alt="homeicon" width="20%" height="7%">
                    <button type="submit" class="teambtn" name="homebtn" onclick="go_to_setting()">Setting</button>
                </div>
            </div>
            <div class="musicplayer">
                <button class="cd" onclick="go_to_song()">
                    <img src="Webimage/cd_btn.PNG"  width="70%" alt="cd" >
                </button>
                <div class="SongName">
                    <h4  id="songName">Song Name</h4>
                </div>
                <div class="ArtistName">
                    <h6  id="artistName">Artist Name</h6>
                </div>
                <script>
                    document.addEventListener("DOMContentLoaded", function () {
                        checkTextLength();
                    });

                    function checkTextLength() {
                        var songNameElement = document.getElementById("songName");
                        var artistNameElement = document.getElementById("artistName");

                        if (songNameElement.scrollWidth > songNameElement.clientWidth) {
                            songNameElement.classList.add("marquee");
                        }

                        if (artistNameElement.scrollWidth > artistNameElement.clientWidth) {
                            artistNameElement.classList.add("marquee");
                        }
                    }
                </script>
                <div class="controlpannel">
                    <button class="controlbtn"><img src="Webimage/backsong_btn.PNG"   width="70%"></button>
                    <button class="controlbtn" onclick="toggleImage()"><img src="Webimage/play_btn.PNG"  width="70%" id="cdImage"></button>
                    <button class="controlbtn"><img src="Webimage/nextsong_btn.PNG"  width="70%"></button>
                </div>
            </div>
        </div>
        <div class="searchbar">
            <div class="searchteam">
                <img src="Webimage/search_icon.PNG" class="search" alt="homeicon" width="7%" height="200%">
                <input type="text" placeholder="Search for songs"  id="textInput" name="search" autocomplete="off">
                <button class="micro_btn" onclick="startSpeechRecognition()"><img src="Webimage/microphone _icon.PNG"  width="110%"></button>
            </div>
            <div class="name">
                <h4 class="Username"><?php echo htmlspecialchars($nameuser); ?></h4>
            </div>
                <?php
                    // 讀取性別
                    $gender = isset($_SESSION['gender']) ? $_SESSION['gender'] : '';

                    // 根據性別顯示不同的圖示
                    if ($gender === 'male') {
                        echo '<img class="sex" src="Webimage/boy_icon.png" alt="Male Icon" width="5%" >';
                    } elseif ($gender === 'female') {
                        echo '<img class="sex" src="Webimage/girl_icon.png" alt="Female Icon" width="5%" >';
                    } else {
                        // 預設為一般圖示
                        echo '<img class="sex" src="Webimage/othersex_icon.png" alt="Default Icon" width="5%" >';
                    }
                ?>
            </div>
        <div class="recommend">
            <div class="for_you">
                <div>
                    <h3 class="foryou">For you</h3>
                </div>
                <div class="groupmainmusic_btn">
                    <button  class="mainmusic_btn" style="background-image: url('Webimage/album.PNG');">
                        <h2>lovan</h2>
                        <p>god of lovan</p>
                    </button>
                    <button  class="mainmusic_btn" style="background-image: url('Webimage/album.PNG');">
                        <h2>lovan</h2>
                        <p>god of lovan</p>
                    </button>
                    <button  class="mainmusic_btn" ></button>
                    <button  class="mainmusic_btn" ></button>
                    <button  class="mainmusic_btn" ></button>
                    <button  class="mainmusic_btn" ></button>
                    <button  class="mainmusic_btn" ></button>
                    <button  class="mainmusic_btn" ></button>
                </div>
            </div>
            <div class="for_you">
                <div>
                    <h3 class="foryou">Recommend</h3>
                </div>
                <div class="groupmainmusic_btn">
                    <button  class="mainmusic_btn" >
                        <h2>lovan</h2>
                        <p>god of lovan</p>
                    </button>
                    <button  class="mainmusic_btn" ></button>
                    <button  class="mainmusic_btn" ></button>
                    <button  class="mainmusic_btn" ></button>
                    <button  class="mainmusic_btn" ></button>
                    <button  class="mainmusic_btn" ></button>
                    <button  class="mainmusic_btn" ></button>
                    <button  class="mainmusic_btn" ></button>
                </div>
            </div>
        </div>
        <div class="style_btngroup">
            <div>
                <button class="style_btn">K-pop</button>
                <button class="style_btn">J-pop</button>
                <button class="style_btn">Jazz</button>
                <button class="style_btnmore">More ></button>
            </div>
        </div>
        <div class="replay">
            <div class="slideshow-container">
                <!-- 圖片 -->
                <div class="slider">
                    <div class="slider-inner">
                        <div class="slide"><img src="Webimage/ad_1.PNG" alt="Slide 1"></div>
                        <div class="slide"><img src="Webimage/ad_2.PNG" alt="Slide 2"></div>
                        <div class="slide"><img src="Webimage/ad_3.PNG" alt="Slide 3"></div>
                        <div class="slide"><img src="Webimage/ad_4.PNG.png" alt="Slide 4"></div>
                        <div class="slide"><img src="Webimage/ad_5.PNG" alt="Slide 5"></div>
                        <div class="slide"><img src="Webimage/ad_6.PNG" alt="Slide 6"></div>
                        <div class="slide"><img src="Webimage/ad_7.PNG" alt="Slide 7"></div>
                    </div>
                </div>
        
                <!-- 點 -->
                <div class="dot-container" style="text-align: center">
                    <span class="dot"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                </div>
        
                <div class="prev-btn">&#10094;</div>
                <div class="next-btn">&#10095;</div>
            </div>
            <script>
                var slideIndex = 0;
                var slides = document.getElementsByClassName("slide");
                var dots = document.getElementsByClassName("dot");
                var autoSlide;
            
                showSlides();
            
                function showSlides() {
                  for (var i = 0; i < slides.length; i++) {
                    slides[i].style.display = "none";
                  }
            
                  slides[slideIndex].style.display = "block";
                  updateDots();
            
                  autoSlide = setInterval(nextSlide, 3000);
                }
            
                function updateDots() {
                  for (var i = 0; i < dots.length; i++) {
                    dots[i].classList.remove("active");
                  }
                  dots[slideIndex].classList.add("active");
                }
            
                function nextSlide() {
                  clearInterval(autoSlide);
                  slideIndex++;
                  if (slideIndex >= slides.length) {
                    slideIndex = 0;
                  }
                  showSlides();
                }
            
                function prevSlide() {
                  clearInterval(autoSlide);
                  slideIndex--;
                  if (slideIndex < 0) {
                    slideIndex = slides.length - 1;
                  }
                  showSlides();
                }
            
                const prevBtn = document.querySelector('.prev-btn');
                const nextBtn = document.querySelector('.next-btn');
            
                prevBtn.addEventListener('click', prevSlide);
                nextBtn.addEventListener('click', nextSlide);
              </script>

        </div>
    </body>
</html>