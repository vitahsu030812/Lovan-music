<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="icon" href="Webimage/logo.png" type="image/x-icon"/>
        <title>Login to LOVAN</title>
        <style>
            @font-face {
                font-family: 'Jack Armstrong';
                src: url('LOVAN/Jack Armstrong.ttf') format('truetype'),
                url('LOVAN/Arial Rounded MT Bold.ttf') format('truetype');
            }

            * {
                margin: 0;
                padding: 0;
                font-family: 'Jack Armstrong';
            }
            body{
                height: 100%;
                background-image: url(Webimage/registerbackground.PNG) ;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-position: center;
                background-size: cover;
            }
            .link-top {
                width: 100%;
                height: 1vh;
                border-top: solid white 0.3vh;
                justify-content: center;
                margin-bottom: 2vh;
                margin-top: 2vh;
                margin: auto;
            }
            section{
                justify-content: center;
                align-items: center;
                display: flex;
                margin-top: 4.5vh;
            }
            .form-box{
                position: relative;
                width: 25vw;
                height: 70vh;
                background:none;
                border-radius: 3vw;
                display: flex;
                justify-content:center;
                align-items: center;
                padding: 2vw;
                box-shadow:0 0 3vw white;
                margin: auto; /* 通过设置 margin: auto; 实现水平居中 */
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
            }
            h2{
                font-size: 1.65vw;
                color: #c499cf;
                text-align: center;
                margin: 1vw;
                margin-bottom: 1vh;
            }
            h3{
                font-size: 4vw;
                color: white;
                text-align: left;
                margin-left: 1vw;
                margin-bottom: 0.5vw;
            }
            .forget{
                font-size: 1vw;
                color: white;
                text-align: right;
            }
            p{
                font-size: 0.5vw;
                color: white;
                text-align: left;
                margin: 0.5vw;
                margin-top: 2vh;
                margin-left: .1vw;
            }
            a{
                color: white;
                font-size: 0.8vw;
            }
            .btnlogin {
                padding: 1vw 1.5vw;
                color: none;
                text-transform: uppercase;
                letter-spacing: 0.4vw;
                text-decoration: none;
                font-size: 1.2vw;
                overflow: hidden;
                transition: 0.2s;
                background: #c499cf;
                border: none;
                border-radius: 0.2vw;
                margin-left: 7vw;
                margin-top: 2vh;
            }

            .btnlogin:hover {
                color: #c499cf;
                background: none;
                box-shadow: 0 0 1vw #c499cf, 0 0 4vw #c499cf;
                transition-delay: 0.1s;
            }
            .logo{
                position: absolute;
                top: 3vw;
                left: 3vw;
            }
            .back{
                position: absolute;
                top: 4vw;
                left: 8vw;
                font-size: 1.3vw;
                background: none;
                border:none;
                color: white;
                margin: 0;
                text-decoration: none;
            }
            label{
                color: #fff;
                text-align: left;
                margin-bottom: 0.5vw;
                font-size: 1.2vw;
                margin-left: 0.5vw;
            }
            .fivegirls{
                margin-top: 1vw;
                margin-left: 4vw;
            }
            input[type="text"]{
                padding: 0.3vw 0.5vw;
                border: 0.2vw white solid;
                cursor: pointer;
                -webkit-border-radius: 0.5vw;
                border-radius: 0.5vw;
                background-color: none;
                color: #e7d292;
                outline: none;
                background: transparent;
                font-size: 1vw;
                font-family: 'Arial Rounded MT Bold', sans-serif;
                margin-left: 0.5vw;
            }
            input[type="email"]{
                padding: 0.3vw 0.5vw;
                border: 0.2vw white solid;
                cursor: pointer;
                -webkit-border-radius: 0.5vw;
                border-radius: 0.5vw;
                background-color: none;
                color: #e7d292;
                outline: none;
                background: transparent;
                font-size: 0.8vw;
                font-family: 'Arial Rounded MT Bold', sans-serif;
                margin-left: 0.5vw;
            }
            input[type="password"]{
                padding: 0.3vw 0.5vw;
                border: 0.2vw white solid;
                cursor: pointer;
                -webkit-border-radius: 0.5vw;
                border-radius: 0.5vw;
                background-color: none;
                color: #e7d292;
                outline: none;
                background: transparent;
                font-family: 'Arial Rounded MT Bold', sans-serif;
                margin-left: 0.5vw;
                width: 13.5vw;
            }
            #password2{
                padding: 0.3vw 0.5vw;
                border: 0.2vw white solid;
                cursor: pointer;
                -webkit-border-radius: 0.5vw;
                border-radius: 0.5vw;
                background-color: none;
                color: #e7d292;
                outline: none;
                background: transparent;
                font-family: 'Arial Rounded MT Bold', sans-serif;
                margin-left: 0.5vw;
                width: 15vw;
            }
            input[type="date"]{
                padding: 0.3vw 0.5vw;
                border: 0.2vw white solid;
                cursor: pointer;
                -webkit-border-radius: 0.5vw;
                border-radius: 0.5vw;
                background-color: none;
                color: #e7d292;
                outline: none;
                background: transparent;
                font-family: 'Arial Rounded MT Bold', sans-serif;
                margin-left: 0.5vw;
                width: 10.5vw;
            }
            input[type="date"]::-webkit-calendar-picker-indicator{
                color: #e7d292;
                background-color: #e7d292;
                border-radius: 0.2vw;
                font-family: 'Arial Rounded MT Bold', sans-serif;
                margin-left: 0.5vw;
            }
            .group {
                margin-top: 0.2vw;
                margin-bottom: -0.2vw;
                margin-left: 0.5vw;
            }
            .radio-group {
                display: inline-block;
                margin-bottom: 1vw;
            }
            .radio-input {
                visibility: hidden;
            }
            .radio-label {
                font-size: 1vw;
                cursor: pointer;
                position: relative;
                padding-left: 1.5vw;
            }
            .radio-button {
                height: 0.8vw;
                width: 0.8vw;
                border: 0.2vw solid #fff;
                border-radius: 50%;
                display: inline-block;
                position: absolute;
                left: 0;
                top: 0;
                bottom: 2;
                margin-bottom: 1vh;
            }
            .radio-button::after {
                content: "";
                display: block;
                height: 0.8vw;
                width: 0.8vw;
                border-radius: 50%;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background-color: #e7d292;
                opacity: 0;
                transition: opacity 0.2s;
            }
            .radio-input:checked ~ .radio-label .radio-button::after {
                opacity: 1;
            }
            .logina{
                margin-left: 0.5vw;
                font-size: 1vw;
                margin-top: 1vh;
                vertical-align: top;
            }
        </style>
    </head>

    <body>
        <?php include 'localhost.php'; ?>
        <div>
            <a href="welcome.php"><img src="Webimage/logowhite.png"  width=55vw height=55vh class="logo" ></a>
            <a class="back"  href="welcome.php">LOVAN MUSIC</a>
        </div>
        <section>
            <div class="form-box">
                <div class="form-value">
                    <form id="registerForm" action="insert.php" method="POST">
                        <h2>hello lovan music</h2>
                        <div class="link-top"></div>
                        <p>
                            <label for="username">Username</label>
                            <input style="font-size: 0.9vw;" id="username" name="username" type="text" maxlength="8" oninput="validateInput(this)" placeholder="8 char max only letters&numbers" size="25vw" required>
                        </p>
                        <script>
                            function validateInput(inputElement) {
                                var inputValue = inputElement.value;
                                var regex = /^[a-zA-Z0-9]+$/;

                                if (!regex.test(inputValue)) {
                                    inputElement.value = inputValue.slice(0, -1);
                                }
                            }
                        </script>
                        <p>
                            <label for="birthday">birthday date</label>
                            <input style="font-size: 0.8vw;" id="birthday" name="birthday" type="date"  size="70vw" required>
                        </p>
                        <p>
                            <label for="email">Email</label>&ensp;
                            <input id="email" name="email" type="email" size="37vw"  required>
                        </p>
                        <p>
                            <label for="password1">Password</label>&thinsp;
                            <input id="password1" name="password1" type="password"  required>
                        </p>
                        <p>
                            <label for="password2">Confirm</label>&thinsp;&thinsp;
                            <input id="password2" name="password2" type="password" required>
                        </p>
                        <p>
                            <label for="gender">gender</label>&ensp;
                            <div class="group">
                                <div class="radio-group">
                                  <input type="radio" class="radio-input" id="female" value="female" name="gender">
                                  <label for="female" class="radio-label">
                                   <span class="radio-button"></span>
                                        female
                                  </label>
                                </div>
                                <div class="radio-group">
                                  <input type="radio" class="radio-input" id="male" value="male" name="gender">
                                  <label for="male" class="radio-label">
                                    <span class="radio-button"></span>
                                        male
                                  </label>
                                </div>
                                
                                <div class="radio-group">
                                  <input type="radio" class="radio-input" id="custom" value="custom" name="gender">
                                  <label for="custom" class="radio-label">
                                    <span class="radio-button"></span>
                                        custom
                                  </label>
                                </div>
                              </div>
                        </p>
                        <div class="link-top"></div>
                        <button type="submit" name="signinButton" class="btnlogin">SIGN up</button>
                    </form>
                    <a href="login.php"  class="logina" size="30px">login</a>
                    <img src="Webimage/fivegirls.png" alt="welcome photo" width="38%" height="35%" class="fivegirls">
                </div>
            </div>
        </section>
    </body>
</html>
