import requests
from bs4 import BeautifulSoup
import csv
import os
import shutil
import mysql.connector

def download_image(url, folder_path):
    response = requests.get(url)
    response.raise_for_status()
    
    # Extracting filename from the URL
    filename = os.path.join(folder_path, url.split("/")[-1])
    
    with open(filename, 'wb') as file:
        file.write(response.content)
    
    return filename

def get_billboard_top_10(download_folder='catchimg'):
    url = "https://www.billboard.com/charts/hot-100/"
    response = requests.get(url)
    response.raise_for_status()  # Raise an HTTPError for bad responses

    soup = BeautifulSoup(response.text, 'html.parser')

    # Find the elements containing song information
    song_elements = soup.find_all('ul', class_='o-chart-results-list-row', limit=10)   
    top_10_songs = []

    # Create download folder if it doesn't exist
    os.makedirs(download_folder, exist_ok=True)
    shutil.rmtree(download_folder, ignore_errors=True)
    os.makedirs(download_folder, exist_ok=True)
    
    for song_element in song_elements[:10]:
        rank = song_element.find('span', class_='c-label').text.strip()
        title = song_element.find('h3', class_='c-title').text.strip()

        artist_element = song_element.find('ul', class_='lrv-a-unstyle-list')
        artist = artist_element.find('span', class_='c-label').text.strip() if artist_element else 'N/A'

        img_element = song_element.find('div', class_='lrv-a-crop-1x1')
        img_url = img_element.find('img', class_='c-lazy-image__img')['data-lazy-src'] if song_element else 'N/A'
        img_path = download_image(img_url, download_folder)

        top_10_songs.append({
            'Rank': rank,
            'Title': title,
            'Artist': artist,
            'link': img_path
        })
    insert_data_into_board_table(top_10_songs)
    return top_10_songs

def insert_data_into_board_table(data):
    conn = mysql.connector.connect(
        host='localhost',
        user='root',
        password='',
        database='lovan'
    )
    cursor = conn.cursor()

    for song in data:
        rank = song.get('Rank', 'N/A')
        artist = song.get('Artist', 'N/A')
        title = song.get('Title', 'N/A')
        file_path = song.get('link', 'N/A')

        cursor.execute('''
            INSERT INTO board (rank, title, artist, file)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE title = VALUES(title), artist = VALUES(artist), file = VALUES(file)
        ''', (rank, title, artist, file_path))

    conn.commit()
    conn.close()

def save_to_csv(data, filename='billboard_top_10.csv'):
    fields = ['Rank', 'Title', 'Artist', 'link']

    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fields)
        writer.writeheader()
        writer.writerows(data)

if __name__ == "__main__":
    top_10_songs_data = get_billboard_top_10()
    save_to_csv(top_10_songs_data)
    print("Data saved to billboard_top_10.csv")

def job():
    top_10_songs_data = get_billboard_top_10()
    save_to_csv(top_10_songs_data)
    print("Data saved to billboard_top_10.csv")
